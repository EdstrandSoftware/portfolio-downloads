"""Shared deterministic Redline drawing primitives; scene choreography is in the companion scene file."""
import cairo, math, random
from pathlib import Path
W,H=1600,900
P={'oyster':'#f1eee6','paper':'#fffdf6','plum':'#322536','gray':'#786b77','coral':'#dc513f','lavender':'#a497b4','rose':'#e9b4a5','edge':'#c6bcae'}
ASSETS=Path('.')
_IMAGES={}
TEXT_LOG=[]
def col(c,v,a=1):
 v=P.get(v,v).lstrip('#');c.set_source_rgba(*(int(v[i:i+2],16)/255 for i in (0,2,4)),a)
def rect(c,x,y,w,h,fill='paper',stroke=None):
 c.rectangle(x,y,w,h);col(c,fill);c.fill_preserve()
 if stroke:col(c,stroke);c.set_line_width(1);c.stroke()
 else:c.new_path()
def text(c,s,x,y,size=32,color='plum',bold=False,mono=False,align='left'):
 c.select_font_face('DejaVu Sans Mono' if mono else 'Liberation Sans',cairo.FONT_SLANT_NORMAL,cairo.FONT_WEIGHT_BOLD if bold else cairo.FONT_WEIGHT_NORMAL);c.set_font_size(size);e=c.text_extents(str(s));xx=x-(e.x_advance if align=='right' else e.x_advance/2 if align=='center' else 0);col(c,color);c.move_to(xx,y);c.show_text(str(s));TEXT_LOG.append((str(s),xx,y,e.x_advance,size))
def line(c,x,y,xx,yy,color='edge',width=2,dash=None):
 c.save();col(c,color);c.set_line_width(width)
 if dash:c.set_dash(dash)
 c.move_to(x,y);c.line_to(xx,yy);c.stroke();c.restore()
def arrow(c,x,y,xx,yy,color='lavender',width=3):
 if math.hypot(xx-x,yy-y)<1:return
 line(c,x,y,xx,yy,color,width);a=math.atan2(yy-y,xx-x)
 for da in [-.5,.5]:line(c,xx,yy,xx-15*math.cos(a+da),yy-15*math.sin(a+da),color,width)
def paper(c,x,y,w,h,spine=None):
 rect(c,x+7,y+10,w,h,'#d5d0ca');rect(c,x,y,w,h,'paper','edge');line(c,x+2,y+2,x+w-2,y+2,'paper',2)
 for yy in range(int(y+10),int(y+h-5),12):line(c,x+w-25,yy,x+w-7,yy+8,'edge',.5)
 if spine:rect(c,x,y,7,h,spine)
def outline(c,x,y,w,h,color='coral',width=3):
 c.save();c.rectangle(x,y,w,h);col(c,color);c.set_line_width(width);c.stroke();c.restore()
def clamp(v):return max(0,min(1,v))
def ease(v):
 v=clamp(v);return v*v*(3-2*v)
def progress(t,start,dur=1):return ease((t-start)/dur)
def mix(a,b,v):return a+(b-a)*v
def alpha(c,a,fn):
 c.push_group();fn();pat=c.pop_group();c.set_source(pat);c.paint_with_alpha(clamp(a))
def translate(c,x,y,fn):
 c.save();c.translate(x,y);fn();c.restore()
def image(c,name,x,y,w,h,crop=None):
 key=str(ASSETS/name)
 if key not in _IMAGES:_IMAGES[key]=cairo.ImageSurface.create_from_png(key)
 im=_IMAGES[key];iw,ih=im.get_width(),im.get_height();sx,sy,sw,sh=crop or (0,0,iw,ih)
 c.save();c.rectangle(x,y,w,h);c.clip();c.translate(x,y);c.scale(w/sw,h/sh);c.set_source_surface(im,-sx,-sy);c.paint();c.restore()
def pill(c,label,x,y,w=210,color='plum'):
 rect(c,x,y,w,48,color);text(c,label,x+15,y+34,27,'paper',bold=True)
def tick(c,x,y,color='plum'):
 line(c,x,y,x+10,y+10,color,3);line(c,x+10,y+10,x+30,y-13,color,3)
def background():
 s=cairo.ImageSurface(cairo.FORMAT_RGB24,W,H);c=cairo.Context(s);rect(c,0,0,W,H,'oyster');rng=random.Random(41);col(c,'plum',.06)
 for _ in range(26000):c.rectangle(rng.random()*W,rng.random()*H,.65,.6)
 c.fill();return s
BG=background()
def frame(c,project,index,title,subtitle='',mode='ILLUSTRATED EXPLANATION'):
 c.set_source_surface(BG);c.paint();text(c,project.upper(),80,66,26,'gray',mono=True);text(c,f'{index+1:02d} / 11',1520,66,26,'gray',mono=True,align='right');line(c,80,90,1520,90)
 text(c,title,80,165,56,'plum',True)
 if subtitle:text(c,subtitle,80,221,30,'gray')
 line(c,80,781,1520,781);text(c,'FICTIONAL DATA · '+mode,80,820,26,'gray',mono=True)
 text(c,'AI-ASSISTED VIDEO',1520,820,26,'gray',mono=True,align='right')
