"""Read AcroForm text values, map explicitly, and publish an auditable batch.

No OCR, network requests, source edits, numeric coercion, or whitespace cleanup.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile
from typing import Any

from pypdf import PdfReader
from pypdf.generic import TextStringObject, NullObject
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.utils import get_column_letter

VERSION = "1.0.0"
MAX_FILES = 1000
MAX_BYTES = 20 * 1024 * 1024
MAX_FIELDS = 200
MAX_PAGES = 100
ROOT = Path(__file__).resolve().parents[1]
ILLEGAL_XML = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff\ufffe\uffff]")


class RejectedPDF(ValueError):
    def __init__(self, code: str, detail: str):
        self.code, self.detail = code, detail
        super().__init__(detail)


def read_schema(path: Path) -> tuple[dict, bytes]:
    data = path.read_bytes()
    schema = json.loads(data)
    if not isinstance(schema, dict):
        raise ValueError("Schema must be a JSON object")
    fields = schema.get("fields")
    if not isinstance(fields, list) or not fields:
        raise ValueError("Schema must contain a non-empty fields array")
    names: set[str] = set()
    aliases: set[str] = set()
    labels = {"source file", "status", "field count", "sha-256"}
    for f in fields:
        if not isinstance(f, dict):
            raise ValueError("Each schema field must be a JSON object")
        name, label, variants = f.get("name"), f.get("label"), f.get("aliases")
        if not isinstance(name, str) or not name or name in names:
            raise ValueError("Schema canonical names must be unique non-empty strings")
        if not isinstance(label, str) or not label:
            raise ValueError("Every field needs a label")
        if label.casefold() in labels or not excel_supported(label):
            raise ValueError("Labels must be unique (case-insensitive), XLSX-safe and not use metadata headers")
        labels.add(label.casefold())
        if not isinstance(variants, list) or not variants:
            raise ValueError(f"No aliases for {name}")
        for alias in variants:
            if not isinstance(alias, str) or not alias or alias in aliases:
                raise ValueError("Schema aliases must be unique non-empty strings")
            aliases.add(alias)
        if "required" in f and not isinstance(f["required"], bool):
            raise ValueError("required must be a boolean")
        names.add(name)
    return schema, data


def object_key(obj: Any) -> tuple:
    ref = getattr(obj, "indirect_reference", None)
    return (ref.idnum, ref.generation) if ref else ("direct", id(obj))


def extract_fields(data: bytes) -> list[dict]:
    """Traverse fields instead of get_fields(), which can mask duplicate names.

    Read canonical stored values. Check that every page widget reaches a known
    terminal field; orphaned widget-only values are deliberately not repaired.
    """
    reader = PdfReader(io.BytesIO(data), strict=True)
    if reader.is_encrypted:
        raise RejectedPDF("encrypted", "Encrypted PDFs require a separate authorized workflow")
    if len(reader.pages) > MAX_PAGES:
        raise RejectedPDF("page_limit", f"More than {MAX_PAGES} pages")
    root = reader.trailer["/Root"].get_object()
    acro = root.get("/AcroForm")
    if not acro:
        raise RejectedPDF("non_fillable", "No AcroForm; flattened/scanned PDFs are not supported")
    acro = acro.get_object()
    if "/XFA" in acro:
        raise RejectedPDF("xfa_unsupported", "XFA forms are outside this AcroForm-only demo")
    roots = acro.get("/Fields", [])
    if not roots:
        raise RejectedPDF("non_fillable", "No canonical AcroForm field tree")
    found, seen_nodes, names, terminal_keys = [], set(), set(), set()

    def visit(ref: Any, prefix: str = "", inherited: dict | None = None, depth: int = 0):
        node = ref.get_object()
        key = object_key(node)
        if key in seen_nodes or depth > 32:
            raise RejectedPDF("invalid_field_tree", "Repeated/cyclic field object or excessive nesting")
        seen_nodes.add(key)
        effective = dict(inherited or {})
        for k in ("/FT", "/V"):
            if k in node:
                effective[k] = node[k]
        local = str(node.get("/T", ""))
        name = ".".join(x for x in (prefix, local) if x)
        kids = [x.get_object() for x in node.get("/Kids", [])]
        # Children with their own partial names are fields; unnamed kids are
        # widget appearances of this terminal field.
        field_kids = [k for k in kids if "/T" in k or k.get("/Subtype") != "/Widget"]
        if field_kids:
            for child in field_kids:
                visit(child, name, effective, depth + 1)
            return
        if not name or name in names:
            raise RejectedPDF("duplicate_field_name", f"Missing or duplicate field name: {name!r}")
        names.add(name)
        terminal_keys.add(key)
        if effective.get("/FT") != "/Tx":
            raise RejectedPDF("non_text_field", f"Field {name!r} is not a text field")
        value = effective.get("/V")
        if value is None or isinstance(value, NullObject):
            state, text = "no_value", None
        elif isinstance(value, (TextStringObject, str)):
            text = str(value)
            state = "empty" if text == "" else "value"
        else:
            raise RejectedPDF("non_string_value", f"Field {name!r} has a non-text value")
        found.append({"field_name": name, "field_type": "/Tx", "value_state": state, "value": text})
        if len(found) > MAX_FIELDS:
            raise RejectedPDF("field_limit", f"More than {MAX_FIELDS} text fields")

    for ref in roots:
        visit(ref)
    if not found:
        raise RejectedPDF("non_fillable", "No terminal text fields")
    for page in reader.pages:
        for ref in page.get("/Annots", []):
            widget = ref.get_object()
            if widget.get("/Subtype") != "/Widget":
                continue
            current, visited = widget, set()
            while object_key(current) not in terminal_keys:
                key = object_key(current)
                if key in visited or "/Parent" not in current:
                    raise RejectedPDF("orphan_widget", "A page widget is not attached to the canonical field tree")
                visited.add(key)
                current = current["/Parent"].get_object()
            if current is not widget and "/V" in widget:
                if widget["/V"] != current.get("/V"):
                    raise RejectedPDF("widget_value_conflict", "Widget value differs from its parent field")
    return found


def map_fields(raw: list[dict], schema: dict) -> tuple[dict, dict, list[dict]]:
    by_name = {f["field_name"]: f for f in raw}
    mapped, states, issues, known = {}, {}, [], set()
    for field in schema["fields"]:
        canonical = field["name"]
        aliases = [a for a in field["aliases"] if a in by_name]
        known.update(field["aliases"])
        if len(aliases) > 1:
            raise RejectedPDF("schema_conflict", f"Multiple aliases for {canonical}: {', '.join(aliases)}")
        source = by_name[aliases[0]] if aliases else None
        state = source["value_state"] if source else "absent"
        states[canonical] = {"state": state, "source_field": aliases[0] if aliases else None}
        mapped[canonical] = source["value"] if source else None
        if state != "value":
            required = field.get("required", False)
            issues.append({"severity": "warning" if required else "info", "code": f"{'required' if required else 'optional'}_{state}", "field": canonical, "detail": f"{field['label']}: {state}; source text was not invented"})
    for name in sorted(set(by_name) - known):
        issues.append({"severity": "info", "code": "extra_field", "field": name, "detail": "Unmapped field preserved in RawFields and audit.json"})
    return mapped, states, issues


def excel_supported(value: str | None) -> bool:
    return value is None or (len(value) <= 32767 and not ILLEGAL_XML.search(value))


def text_cell(cell, value):
    """Explicit string type prevents formula execution without changing text."""
    if isinstance(value, str):
        if not excel_supported(value):
            value = "[UNREPRESENTABLE IN XLSX: see audit.json]"
        cell.value = value
        cell.data_type = "s"
        cell.number_format = "@"
    else:
        cell.value = value


def build_workbook(audit: dict, destination: Path) -> None:
    wb = Workbook()
    wb.remove(wb.active)
    wb.properties.title = "Field Ledger | Fictional PDF extraction demo"
    wb.properties.creator = "AI-assisted personal portfolio demonstration"
    wb.properties.description = "Fictional equipment-service forms. Not client work."
    schema, inputs = audit["schema"], audit["inputs"]
    record_headers = ["Source file", "Status"] + [f["label"] for f in schema["fields"]] + ["Field count", "SHA-256"]
    records = [[r["file"], r["status"]] + [r.get("mapped", {}).get(f["name"]) for f in schema["fields"]] + [len(r["raw_fields"]), r["sha256"]] for r in inputs]
    rawrows = []
    for r in inputs:
        for f in r["raw_fields"]:
            value = f["value"]
            # XLSX cannot represent every Unicode control/length. Never truncate.
            # Exact decoded value remains in audit.json and original PDF.
            display = value if excel_supported(value) else "[UNREPRESENTABLE IN XLSX: see audit.json]"
            rawrows.append([r["file"], f["field_name"], f["field_type"], f["value_state"], display, r["status"]])
    validation = [[r["file"], i["severity"], i["code"], i.get("field", ""), i["detail"]] for r in inputs for i in r["issues"]]
    if not validation:
        validation = [["Batch", "info", "no_issues", "", "No detected issues; source review still recommended"]]

    def sheet(name, title, subtitle, headers, rows, widths):
        ws = wb.create_sheet(name)
        ws.sheet_view.showGridLines = False
        ws.sheet_properties.pageSetUpPr.fitToPage = True
        ws.sheet_properties.tabColor = "167D9A"
        n = len(headers)
        for c in range(1, n + 1):
            cell = ws.cell(1, c)
            cell.fill = PatternFill("solid", fgColor="112D40")
        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=n)
        ws.cell(1, 1, title).font = Font(name="Arial", size=16, color="FFFFFF", bold=True)
        ws.row_dimensions[1].height = 34
        ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=n)
        ws.cell(2, 1, subtitle).font = Font(name="Arial", size=10, color="506A7A", italic=True)
        ws.row_dimensions[2].height = 26
        for row_index, row in enumerate([headers] + rows, 4):
            for col, value in enumerate(row, 1):
                cell = ws.cell(row_index, col)
                text_cell(cell, value)
                cell.font = Font(name="Arial", size=10, color="203747")
                cell.alignment = Alignment(vertical="center", wrap_text=True)
            ws.row_dimensions[row_index].height = 32 if row_index > 4 else 30
        for cell in ws[4]:
            cell.fill = PatternFill("solid", fgColor="167D9A")
            cell.font = Font(name="Arial", size=10, color="FFFFFF", bold=True)
        if rows:
            table = Table(displayName=name + "Table", ref=f"A4:{get_column_letter(n)}{len(rows)+4}")
            table.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
            ws.add_table(table)
        ws.freeze_panes = "C5" if name == "Records" else "B5"
        for i, width in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = width
        ws.print_options.horizontalCentered = True
        ws.page_setup.orientation = "landscape"
        ws.page_setup.paperSize = ws.PAPERSIZE_A3
        ws.page_setup.fitToHeight, ws.page_setup.fitToWidth = 0, 1
        ws.print_title_rows = "1:4"
        ws.print_area = f"A1:{get_column_letter(n)}{len(rows)+4}"
        return ws

    sheet("Records", "FIELD LEDGER / Extracted records", "FICTIONAL DEMO | One row per PDF, including quarantine rows. All source field values remain text.", record_headers, records, [32, 19, 18, 17, 30, 23, 31, 22, 23, 18, 20, 46, 25, 27, 13, 68])
    sheet("RawFields", "FIELD LEDGER / Source field ledger", "FICTIONAL DEMO | Exact decoded /V values. Empty, no_value and absent are different; absent schema fields appear in Validation.", ["Source file", "Original field name", "PDF type", "Value state", "Exact source value", "Record status"], rawrows, [32, 27, 13, 17, 76, 19])
    sheet("Validation", "FIELD LEDGER / Exceptions to review", "FICTIONAL DEMO | Quarantine errors block mapping. Warnings need review; informational gaps remain explicit.", ["Source file", "Severity", "Code", "Field", "Explanation"], validation, [32, 14, 28, 24, 94])
    counts = Counter(r["status"] for r in inputs)
    summary = [
        ["Purpose", "AI-assisted personal portfolio demo; fictional data; not client work"],
        ["Run ID", audit["run_id"]], ["UTC run time", audit["created_utc"]],
        ["PDF inputs inventoried", len(inputs)],
        ["Extracted", counts["extracted"]], ["Needs review", counts["needs_review"]],
        ["Quarantined", counts["quarantined"]], ["Ignored non-PDF entries", len(audit["ignored_entries"])],
        ["Reconciliation", f"{len(inputs)} inputs = {counts['extracted']} extracted + {counts['needs_review']} needs review + {counts['quarantined']} quarantined"],
        ["Stored raw text fields", len(rawrows)], ["Validation issues", sum(len(r["issues"]) for r in inputs)],
        ["Schema SHA-256", audit["schema_sha256"]], ["Tool version", VERSION],
        ["Exact audit trail", "audit.json: decoded values, field states, source hashes and every input outcome"],
        ["Quarantine policy", "Copies only; original PDFs are never moved or edited"],
        ["Source-value policy", "No trimming, case changes, numeric/date conversion or formula interpretation"],
        ["Scope", "Canonical text-only AcroForms; no OCR, XFA, signatures or password handling"],
    ]
    sheet("RunSummary", "FIELD LEDGER / Batch receipt", "FICTIONAL DEMO | Counts are run-time results, not live formulas. Re-run the CLI after changing source files.", ["Item", "Value"], summary, [32, 114])
    wb.save(destination)


def publish_bundle(stage: Path, output_dir: Path) -> None:
    """Reserve destination exclusively; publish complete files, receipt last.

    Hard links are same-filesystem and fail rather than replacing an existing
    destination. The final receipt is the complete-bundle marker. Individual
    files are atomic; the directory is intentionally NOT an atomic transaction.
    """
    output_dir.mkdir()  # exclusive even if another process wins the race
    created_files, created_dirs = [], []
    try:
        for directory in sorted(p for p in stage.rglob("*") if p.is_dir()):
            target = output_dir / directory.relative_to(stage)
            target.mkdir()
            created_dirs.append(target)
        files = sorted(p for p in stage.rglob("*") if p.is_file())
        files.sort(key=lambda p: (p.name == "COMPLETE.json", str(p)))
        for source in files:
            target = output_dir / source.relative_to(stage)
            os.link(source, target)
            stat = source.stat()
            created_files.append((target, stat.st_dev, stat.st_ino))
    except Exception:
        for path, device, inode in reversed(created_files):
            try:
                stat = path.lstat()
                if (stat.st_dev, stat.st_ino) == (device, inode):
                    path.unlink()
            except OSError:
                pass
        for path in reversed(created_dirs):
            try:
                path.rmdir()
            except OSError:
                pass
        try:
            output_dir.rmdir()
        except OSError:
            pass
        raise


def process_batch(input_dir: Path, output_dir: Path, schema_path: Path) -> dict:
    input_dir, output_dir = input_dir.resolve(), output_dir.absolute()
    if not input_dir.is_dir():
        raise ValueError("Input directory does not exist")
    if output_dir.exists() or output_dir.is_symlink():
        raise FileExistsError(f"Refusing to overwrite existing output: {output_dir}")
    if output_dir.resolve() == input_dir or input_dir in output_dir.resolve().parents:
        raise ValueError("Output must be outside the input folder")
    schema, schema_bytes = read_schema(schema_path)
    entries = sorted(input_dir.iterdir(), key=lambda p: (p.name.casefold(), p.name))
    pdfs = [p for p in entries if p.suffix.casefold() == ".pdf"]
    if not pdfs:
        raise ValueError("No PDF files found in the top-level input folder")
    if len(pdfs) > MAX_FILES:
        raise ValueError(f"Batch exceeds {MAX_FILES} PDF entries")
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    lock = output_dir.with_name("." + output_dir.name + ".lock")
    fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    os.close(fd)
    stage = None
    try:
        if output_dir.exists():
            raise FileExistsError(f"Output appeared while starting: {output_dir}")
        stage = Path(tempfile.mkdtemp(prefix="." + output_dir.name + ".staging-", dir=output_dir.parent))
        (stage / "quarantine").mkdir()
        audit = {"tool": "Field Ledger", "version": VERSION, "fictional_demo": True, "created_utc": datetime.now(timezone.utc).isoformat(), "schema": schema, "schema_sha256": hashlib.sha256(schema_bytes).hexdigest(), "inputs": [], "ignored_entries": [p.name for p in entries if p.suffix.casefold() != ".pdf"]}
        for path in pdfs:
            record = {"file": path.name, "sha256": None, "status": "quarantined", "raw_fields": [], "mapped": {}, "field_states": {}, "issues": [], "quarantine_copy": None}
            data = None
            try:
                if path.is_symlink() or not path.is_file():
                    raise RejectedPDF("unsafe_entry", "Symlinks and non-regular PDF entries are not opened")
                with path.open("rb") as stream:
                    data = stream.read(MAX_BYTES + 1)
                if len(data) > MAX_BYTES:
                    data = None
                    raise RejectedPDF("size_limit", f"File exceeds {MAX_BYTES // 1024 // 1024} MiB; not copied")
                record["sha256"] = hashlib.sha256(data).hexdigest()
                record["raw_fields"] = extract_fields(data)
                if any(not excel_supported(f["value"]) or not excel_supported(f["field_name"]) for f in record["raw_fields"]):
                    raise RejectedPDF("xlsx_text_limit", "A value or name cannot be represented losslessly in XLSX; see audit.json")
                mapped, states, issues = map_fields(record["raw_fields"], schema)
                record.update(mapped=mapped, field_states=states, issues=issues)
                record["status"] = "needs_review" if any(i["severity"] == "warning" for i in issues) else "extracted"
            except RejectedPDF as exc:
                record["issues"].append({"severity": "error", "code": exc.code, "field": "", "detail": exc.detail})
            except (OSError, ValueError, TypeError, KeyError, RecursionError) as exc:
                record["issues"].append({"severity": "error", "code": "unreadable_pdf", "field": "", "detail": f"{type(exc).__name__}: {str(exc)[:250]}"})
            except Exception as exc:
                # pypdf has several distinct parser errors. Record, do not skip.
                record["issues"].append({"severity": "error", "code": "parser_error", "field": "", "detail": f"{type(exc).__name__}: {str(exc)[:250]}"})
            if record["status"] == "quarantined" and data is not None:
                copy = stage / "quarantine" / path.name
                copy.write_bytes(data)
                record["quarantine_copy"] = "quarantine/" + path.name
            audit["inputs"].append(record)
        run_material = json.dumps({"schema": audit["schema_sha256"], "inputs": [(r["file"], r["sha256"]) for r in audit["inputs"]]}, ensure_ascii=True, sort_keys=True).encode()
        audit["run_id"] = hashlib.sha256(run_material).hexdigest()[:16]
        audit["counts"] = dict(Counter(r["status"] for r in audit["inputs"]))
        (stage / "audit.json").write_text(json.dumps(audit, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
        (stage / "schema-used.json").write_bytes(schema_bytes)
        build_workbook(audit, stage / "extracted-records.xlsx")
        receipt = {"complete": True, "run_id": audit["run_id"], "pdf_count": len(pdfs), "counts": audit["counts"], "files_sha256": {name: hashlib.sha256((stage / name).read_bytes()).hexdigest() for name in ("audit.json", "schema-used.json", "extracted-records.xlsx")}}
        (stage / "COMPLETE.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        if output_dir.exists() or output_dir.is_symlink():
            raise FileExistsError("Output appeared before commit; refusing to overwrite")
        publish_bundle(stage, output_dir)
        return audit
    finally:
        if stage is not None:
            shutil.rmtree(stage)
        lock.unlink(missing_ok=True)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Extract canonical text-only PDF AcroForms into an auditable XLSX batch. No OCR.")
    parser.add_argument("input", type=Path, help="Folder of PDFs (top-level only)")
    parser.add_argument("output", type=Path, help="NEW output folder; never overwritten")
    parser.add_argument("--schema", type=Path, default=ROOT / "schema.json", help="Explicit canonical-field mapping JSON")
    args = parser.parse_args(argv)
    try:
        audit = process_batch(args.input, args.output, args.schema)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    counts = audit["counts"]
    print(f"Field Ledger {VERSION} | run {audit['run_id']}")
    print(f"{len(audit['inputs'])} PDFs accounted for: " + ", ".join(f"{counts.get(s, 0)} {s}" for s in ("extracted", "needs_review", "quarantined")))
    print(f"Output: {args.output / 'extracted-records.xlsx'}")
    print("Review Validation and audit.json before using extracted data.")
    return 2 if counts.get("quarantined", 0) or counts.get("needs_review", 0) else 0


if __name__ == "__main__":
    sys.exit(main())
