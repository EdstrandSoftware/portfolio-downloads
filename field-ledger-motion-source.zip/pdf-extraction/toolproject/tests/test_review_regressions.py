"""Independent review cases for text preservation and safe batch publication."""
from __future__ import annotations
import hashlib
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from openpyxl import load_workbook
from pypdf import PdfReader, PdfWriter
from pypdf.generic import NameObject, TextStringObject, NullObject

from src.extractor import ROOT, process_batch, publish_bundle, read_schema, main
from tools.generate_demo import generate


class ReviewRegressions(unittest.TestCase):
    fixtures = ROOT / "demo" / "inputs"

    def modified_pdf(self, value=None, remove=False):
        writer = PdfWriter()
        writer.clone_document_from_reader(PdfReader(self.fixtures / "intake-01-template-A.pdf"))
        field = writer.root_object["/AcroForm"]["/Fields"][0].get_object()
        if remove:
            del field["/V"]
        else:
            field[NameObject("/V")] = NullObject() if value is None else TextStringObject(value)
        output = io.BytesIO()
        writer.write(output)
        return output.getvalue()

    def test_clean_batch_summary_does_not_count_display_placeholder(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp); source = d / "in"; source.mkdir()
            (source / "one.pdf").write_bytes((self.fixtures / "intake-01-template-A.pdf").read_bytes())
            audit = process_batch(source, d / "out", ROOT / "schema.json")
            self.assertEqual(sum(len(record["issues"]) for record in audit["inputs"]), 0)
            wb = load_workbook(d / "out" / "extracted-records.xlsx")
            summary = dict(wb["RunSummary"].iter_rows(min_row=5, values_only=True))
            self.assertEqual(summary["Validation issues"], 0)
            wb.close()

    def test_run_id_values_and_source_bytes_repeatable(self):
        before = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in self.fixtures.iterdir()}
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp)
            a = process_batch(self.fixtures, d / "a", ROOT / "schema.json")
            b = process_batch(self.fixtures, d / "b", ROOT / "schema.json")
            self.assertEqual(a["run_id"], b["run_id"])
            self.assertEqual(a["inputs"], b["inputs"])
        after = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in self.fixtures.iterdir()}
        self.assertEqual(before, after)

    def test_every_mapped_workbook_value_against_manifest(self):
        expected = json.loads((ROOT / "demo" / "expected-values.json").read_text(encoding="utf-8"))
        schema, _ = read_schema(ROOT / "schema.json")
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "out"
            process_batch(self.fixtures, out, ROOT / "schema.json")
            wb = load_workbook(out / "extracted-records.xlsx", data_only=False)
            rows = {r[0]: r for r in wb["Records"].iter_rows(min_row=5, values_only=True)}
            for filename, fields in expected.items():
                for column, spec in enumerate(schema["fields"], 2):
                    aliases = [name for name in spec["aliases"] if name in fields]
                    value = fields[aliases[0]] if aliases else None
                    # XLSX displays empty/null/absent as blank. audit.json and
                    # RawFields/Validation retain their distinct source states.
                    self.assertEqual(rows[filename][column], None if value == "" else value, (filename, spec["name"]))
            wb.close()

    def test_unicode_multiline_formula_prefixes_remain_exact_text(self):
        values = ['=HYPERLINK("https://example.invalid")', "+1+2", "-1+2", "@SUM(1,2)", "000001", "日本語 👩🏽‍🔧", "  \tline1\r\nline2  "]
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp); source = d / "in"; source.mkdir()
            for i, value in enumerate(values):
                (source / f"{i}.pdf").write_bytes(self.modified_pdf(value))
            audit = process_batch(source, d / "out", ROOT / "schema.json")
            wb = load_workbook(d / "out" / "extracted-records.xlsx", data_only=False)
            for i, value in enumerate(values):
                self.assertEqual(audit["inputs"][i]["mapped"]["service_id"], value)
                cell = wb["Records"].cell(i + 5, 3)
                self.assertEqual(cell.value, value)
                self.assertEqual(cell.data_type, "s")
            self.assertFalse(any(c.data_type == "f" for sheet in wb for row in sheet for c in row))
            wb.close()

    def test_xlsx_limits_quarantine_without_losing_json_values(self):
        values = ["x\x01y", "x" * 32768]
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp); source = d / "in"; source.mkdir()
            for i, value in enumerate(values):
                (source / f"{i}.pdf").write_bytes(self.modified_pdf(value))
            audit = process_batch(source, d / "out", ROOT / "schema.json")
            self.assertEqual(audit["counts"], {"quarantined": 2})
            for record, value in zip(audit["inputs"], values):
                self.assertEqual(record["raw_fields"][0]["value"], value)
                self.assertEqual(record["issues"][0]["code"], "xlsx_text_limit")
            saved = json.loads((d / "out" / "audit.json").read_text(encoding="utf-8"))
            self.assertEqual([r["raw_fields"][0]["value"] for r in saved["inputs"]], values)

    def test_required_missing_null_and_empty_pdf_values(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp); source = d / "in"; source.mkdir()
            data = [self.modified_pdf(remove=True), self.modified_pdf(None), self.modified_pdf("")]
            for i, value in enumerate(data):
                (source / f"{i}.pdf").write_bytes(value)
            audit = process_batch(source, d / "out", ROOT / "schema.json")
            self.assertEqual(audit["counts"], {"needs_review": 3})
            self.assertEqual([r["field_states"]["service_id"]["state"] for r in audit["inputs"]], ["no_value", "no_value", "empty"])

    def test_input_hardlink_is_read_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp); source = d / "in"; source.mkdir()
            original = d / "original.pdf"
            original.write_bytes((self.fixtures / "intake-01-template-A.pdf").read_bytes())
            try:
                os.link(original, source / "linked.pdf")
            except OSError as exc:
                self.skipTest(f"Hardlink creation unavailable: {exc}")
            before = original.read_bytes(); inode = original.stat().st_ino
            audit = process_batch(source, d / "out", ROOT / "schema.json")
            self.assertEqual(audit["counts"], {"extracted": 1})
            self.assertEqual(original.read_bytes(), before)
            self.assertEqual((source / "linked.pdf").stat().st_ino, inode)

    def test_input_symlink_is_accounted_without_reading_target(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp); source = d / "in"; source.mkdir()
            try:
                (source / "linked.pdf").symlink_to(self.fixtures / "intake-01-template-A.pdf")
            except OSError as exc:
                self.skipTest(f"Symlink creation unavailable: {exc}")
            audit = process_batch(source, d / "out", ROOT / "schema.json")
            record = audit["inputs"][0]
            self.assertEqual(record["issues"][0]["code"], "unsafe_entry")
            self.assertIsNone(record["sha256"])
            self.assertIsNone(record["quarantine_copy"])

    def test_output_inside_input_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp)
            (d / "input.pdf").write_bytes((self.fixtures / "intake-01-template-A.pdf").read_bytes())
            with self.assertRaises(ValueError):
                process_batch(d, d / "new" / "out", ROOT / "schema.json")
            self.assertFalse((d / "new").exists())

    def test_dangling_output_symlink_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp); target = d / "output"
            try:
                target.symlink_to(d / "does-not-exist")
            except OSError as exc:
                self.skipTest(f"Symlink creation unavailable: {exc}")
            with self.assertRaises(FileExistsError):
                process_batch(self.fixtures, target, ROOT / "schema.json")
            self.assertTrue(target.is_symlink())

    def test_output_created_before_commit_not_replaced(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp); target = d / "out"
            from src.extractor import build_workbook
            def concurrent_destination(audit, destination):
                build_workbook(audit, destination)
                target.mkdir()
                (target / "keep.txt").write_text("untouched", encoding="utf-8")
            with patch("src.extractor.build_workbook", side_effect=concurrent_destination):
                with self.assertRaises(FileExistsError):
                    process_batch(self.fixtures, target, ROOT / "schema.json")
            self.assertEqual((target / "keep.txt").read_text(encoding="utf-8"), "untouched")

    def test_publication_refuses_existing_empty_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp); stage = d / "stage"; stage.mkdir()
            (stage / "payload.txt").write_text("staged", encoding="utf-8")
            target = d / "out"; target.mkdir(); before = target.stat().st_ino
            with self.assertRaises(FileExistsError):
                publish_bundle(stage, target)
            self.assertEqual(target.stat().st_ino, before)
            self.assertEqual(list(target.iterdir()), [])

    def test_publication_receipt_last_and_failure_rolls_back(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp); stage = d / "stage"; stage.mkdir()
            for name in ["a.txt", "b.txt", "COMPLETE.json"]:
                (stage / name).write_text(name, encoding="utf-8")
            target = d / "out"; calls = []; real_link = os.link
            def checked_link(source, destination):
                self.assertFalse((target / "COMPLETE.json").exists())
                calls.append(Path(source).name)
                real_link(source, destination)
            with patch("src.extractor.os.link", side_effect=checked_link):
                publish_bundle(stage, target)
            self.assertEqual(calls[-1], "COMPLETE.json")
            target2 = d / "failed"; count = [0]
            def failed_link(source, destination):
                count[0] += 1
                if count[0] == 2:
                    raise OSError("Simulated publication failure")
                real_link(source, destination)
            with patch("src.extractor.os.link", side_effect=failed_link):
                with self.assertRaises(OSError):
                    publish_bundle(stage, target2)
            self.assertFalse(target2.exists())

    def test_publication_rollback_preserves_concurrent_replacement(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp); stage = d / "stage"; stage.mkdir()
            for name in ["a.txt", "b.txt", "COMPLETE.json"]:
                (stage / name).write_text(name, encoding="utf-8")
            target = d / "out"; real_link = os.link; count = [0]
            def conflicting_link(source, destination):
                count[0] += 1
                if count[0] == 2:
                    (target / "a.txt").unlink()
                    (target / "a.txt").write_text("external replacement", encoding="utf-8")
                    raise OSError("Simulated concurrent change")
                real_link(source, destination)
            with patch("src.extractor.os.link", side_effect=conflicting_link):
                with self.assertRaises(OSError):
                    publish_bundle(stage, target)
            self.assertEqual((target / "a.txt").read_text(encoding="utf-8"), "external replacement")
            self.assertFalse((target / "COMPLETE.json").exists())

    def test_generated_fixture_bytes_repeatable(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp)
            generate(d / "inputs")
            for fixture in self.fixtures.iterdir():
                self.assertEqual(fixture.read_bytes(), (d / "inputs" / fixture.name).read_bytes(), fixture.name)
            self.assertEqual(json.loads((d / "expected-values.json").read_text(encoding="utf-8")), json.loads((ROOT / "demo" / "expected-values.json").read_text(encoding="utf-8")))

    def test_generator_refuses_existing_ground_truth_sidecar(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp); sidecar = d / "expected-values.json"
            sidecar.write_text("KEEP ME", encoding="utf-8")
            with self.assertRaises(FileExistsError):
                generate(d / "inputs")
            self.assertEqual(sidecar.read_text(encoding="utf-8"), "KEEP ME")
            self.assertFalse((d / "inputs").exists())

    def test_malformed_schema_shapes_exit_cleanly(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp)
            for i, schema in enumerate([[], {"fields": [2]}]):
                path = d / f"schema{i}.json"; path.write_text(json.dumps(schema), encoding="utf-8")
                self.assertEqual(main([str(self.fixtures), str(d / f"out{i}"), "--schema", str(path)]), 1)
                self.assertFalse((d / f"out{i}").exists())

    def test_duplicate_or_reserved_record_labels_rejected(self):
        invalid_schemas = [
            {"fields": [{"name": "x", "label": "Status", "aliases": ["ServiceID"]}]},
            {"fields": [{"name": "x", "label": "Repeated", "aliases": ["ServiceID"]}, {"name": "y", "label": "repeated", "aliases": ["AssetTag"]}]},
        ]
        with tempfile.TemporaryDirectory() as tmp:
            for i, schema in enumerate(invalid_schemas):
                path = Path(tmp) / f"{i}.json"; path.write_text(json.dumps(schema), encoding="utf-8")
                with self.assertRaises(ValueError):
                    read_schema(path)


if __name__ == "__main__":
    unittest.main()
