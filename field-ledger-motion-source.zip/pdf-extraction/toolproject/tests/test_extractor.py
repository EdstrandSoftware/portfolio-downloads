from __future__ import annotations
import copy
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from pypdf import PdfReader, PdfWriter
from pypdf.generic import NameObject, TextStringObject, ArrayObject
from openpyxl import load_workbook
from src.extractor import ROOT, RejectedPDF, extract_fields, map_fields, process_batch, read_schema, main


class ExtractionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.schema, _ = read_schema(ROOT / "schema.json")
        cls.fixtures = ROOT / "demo" / "inputs"
        cls.expected = json.loads((ROOT / "demo" / "expected-values.json").read_text())

    def test_all_24_forms_exact_values(self):
        for filename, expected in self.expected.items():
            raw = extract_fields((self.fixtures / filename).read_bytes())
            self.assertEqual({r["field_name"]:r["value"] for r in raw}, expected, filename)

    def test_all_24_forms_have_matching_widgets_and_appearances(self):
        for filename, expected in self.expected.items():
            reader = PdfReader(self.fixtures / filename)
            widgets = [a.get_object() for p in reader.pages for a in p.get("/Annots", []) if a.get_object().get("/Subtype") == "/Widget"]
            self.assertEqual(len(widgets), len(expected), filename)
            for widget in widgets:
                self.assertEqual(str(widget.get("/V")), expected[str(widget["/T"])])
                self.assertGreater(len(widget["/AP"]["/N"].get_object().get_data()), 0)

    def test_both_mapping_variants(self):
        for number, variant in [(1,"A"),(13,"B")]:
            raw = extract_fields((self.fixtures / f"intake-{number:02d}-template-{variant}.pdf").read_bytes())
            mapped, states, issues = map_fields(raw, self.schema)
            self.assertEqual(mapped["service_id"], f"SRV-{number:04d}")
            self.assertEqual(mapped["serial_number"], f"{number:09d}")

    def test_empty_versus_absent_versus_no_value(self):
        raw = [{"field_name":"ContactName", "value":"", "value_state":"empty"}, {"field_name":"PhoneNumber", "value":None, "value_state":"no_value"}]
        mapped, states, issues = map_fields(raw, self.schema)
        self.assertEqual(states["contact_name"]["state"], "empty")
        self.assertEqual(states["preferred_slot"]["state"], "absent")
        self.assertEqual(states["phone"]["state"], "no_value")
        self.assertEqual(mapped["contact_name"], "")
        self.assertIsNone(mapped["phone"])

    def test_extra_fields_retained(self):
        raw = extract_fields((self.fixtures / "intake-05-template-A.pdf").read_bytes())
        self.assertIn("InternalReference", [r["field_name"] for r in raw])
        self.assertIn("extra_field", [i["code"] for i in map_fields(raw,self.schema)[2]])

    def test_unicode_and_whitespace(self):
        r3 = extract_fields((self.fixtures / "intake-03-template-A.pdf").read_bytes())
        self.assertEqual(map_fields(r3,self.schema)[0]["contact_name"], "José Müller")
        r6 = extract_fields((self.fixtures / "intake-06-template-A.pdf").read_bytes())
        self.assertEqual(map_fields(r6,self.schema)[0]["issue_description"], "  Retain two leading and trailing spaces  ")

    def test_nonfillable_rejected(self):
        with self.assertRaises(RejectedPDF) as cm:
            extract_fields((self.fixtures / "reject-01-flat-document.pdf").read_bytes())
        self.assertEqual(cm.exception.code, "non_fillable")

    def test_schema_conflict_rejected(self):
        raw = extract_fields((self.fixtures / "reject-03-schema-conflict.pdf").read_bytes())
        with self.assertRaises(RejectedPDF) as cm: map_fields(raw,self.schema)
        self.assertEqual(cm.exception.code, "schema_conflict")

    def test_schema_duplicate_alias_rejected(self):
        schema = copy.deepcopy(self.schema)
        schema["fields"][1]["aliases"].append("ServiceID")
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"schema.json"; p.write_text(json.dumps(schema))
            with self.assertRaises(ValueError): read_schema(p)

    def modified_pdf(self, mutate):
        reader=PdfReader(self.fixtures / "intake-01-template-A.pdf")
        writer=PdfWriter(); writer.clone_document_from_reader(reader)
        mutate(writer)
        out=io.BytesIO(); writer.write(out); return out.getvalue()

    def test_no_value_from_pdf(self):
        def change(w): del w.root_object["/AcroForm"]["/Fields"][0].get_object()["/V"]
        raw=extract_fields(self.modified_pdf(change))
        self.assertEqual(raw[0]["value_state"], "no_value")

    def test_duplicate_pdf_names_rejected(self):
        def change(w): w.root_object["/AcroForm"]["/Fields"][1].get_object()[NameObject("/T")]=TextStringObject("ServiceID")
        with self.assertRaises(RejectedPDF) as cm: extract_fields(self.modified_pdf(change))
        self.assertEqual(cm.exception.code,"duplicate_field_name")

    def test_orphan_widget_rejected(self):
        def change(w): del w.root_object["/AcroForm"]["/Fields"][0]
        with self.assertRaises(RejectedPDF) as cm: extract_fields(self.modified_pdf(change))
        self.assertEqual(cm.exception.code,"orphan_widget")

    def test_encrypted_rejected(self):
        writer=PdfWriter(); writer.add_blank_page(width=612,height=792)
        writer.encrypt("fictional-demo-password")
        out=io.BytesIO(); writer.write(out); data=out.getvalue()
        with self.assertRaises(RejectedPDF) as cm: extract_fields(data)
        self.assertEqual(cm.exception.code,"encrypted")

    def test_all_inputs_accounted_and_quarantine_copies(self):
        with tempfile.TemporaryDirectory() as d:
            audit=process_batch(self.fixtures,Path(d)/"out",ROOT/"schema.json")
            self.assertEqual(len(audit["inputs"]),27)
            self.assertEqual(audit["counts"],{"extracted":23,"needs_review":1,"quarantined":3})
            for r in audit["inputs"]:
                self.assertEqual(r["sha256"],hashlib.sha256((self.fixtures/r["file"]).read_bytes()).hexdigest())
                if r["status"]=="quarantined":
                    self.assertEqual((Path(d)/"out"/r["quarantine_copy"]).read_bytes(),(self.fixtures/r["file"]).read_bytes())
            self.assertTrue((Path(d)/"out"/"COMPLETE.json").exists())

    def test_xlsx_formula_like_and_leading_zero_are_text(self):
        with tempfile.TemporaryDirectory() as d:
            dest=Path(d)/"out"; process_batch(self.fixtures,dest,ROOT/"schema.json")
            wb=load_workbook(dest/"extracted-records.xlsx",data_only=False)
            self.assertEqual(wb.sheetnames,["Records","RawFields","Validation","RunSummary"])
            ws=wb["Records"]
            self.assertEqual(ws["K5"].value,"000000001")
            self.assertEqual(ws["K5"].data_type,"s")
            self.assertEqual(ws["L11"].value,"=1+1")
            self.assertEqual(ws["L11"].data_type,"s")
            self.assertEqual(ws["L23"].value,"+SUM(1,2)")
            for sheet in wb:
                self.assertFalse(any(c.data_type=="f" for row in sheet for c in row))
            wb.close()

    def test_refuse_overwrite(self):
        with tempfile.TemporaryDirectory() as d:
            target=Path(d)/"out"; target.mkdir(); (target/"keep.txt").write_text("untouched")
            with self.assertRaises(FileExistsError): process_batch(self.fixtures,target,ROOT/"schema.json")
            self.assertEqual((target/"keep.txt").read_text(),"untouched")

    def test_failure_publishes_nothing(self):
        with tempfile.TemporaryDirectory() as d:
            target=Path(d)/"out"
            with patch("src.extractor.build_workbook",side_effect=OSError("simulated disk failure")):
                with self.assertRaises(OSError): process_batch(self.fixtures,target,ROOT/"schema.json")
            self.assertFalse(target.exists())
            self.assertEqual(list(Path(d).iterdir()),[])

    def test_cli_review_exit_code(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(main([str(self.fixtures),str(Path(d)/"out")]),2)

    def test_no_pdf_is_configuration_error(self):
        with tempfile.TemporaryDirectory() as d:
            source=Path(d)/"in"; source.mkdir()
            with self.assertRaises(ValueError): process_batch(source,Path(d)/"out",ROOT/"schema.json")

    def test_unreadable_entry_is_reported(self):
        with tempfile.TemporaryDirectory() as d:
            source=Path(d)/"in"; source.mkdir(); (source/"not-a-file.pdf").mkdir()
            audit=process_batch(source,Path(d)/"out",ROOT/"schema.json")
            self.assertEqual(audit["inputs"][0]["issues"][0]["code"],"unsafe_entry")


if __name__ == "__main__": unittest.main()
