"""Generate deterministic fictional fixtures. Refuses any existing destination."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor

ROOT = Path(__file__).resolve().parents[1]
NAVY, TEAL, GREY = HexColor("#112D40"), HexColor("#167D9A"), HexColor("#506A7A")


def create_pdf(path: Path, fields: list[tuple[str, str, str]], variant="A", title="Equipment service intake"):
    c = canvas.Canvas(str(path), pagesize=(612, 792), invariant=1)
    c.setTitle("FICTIONAL DEMO | Equipment service intake")
    c.setAuthor("AI-assisted personal portfolio demo")
    c.setFillColor(NAVY)
    c.rect(0, 680, 612, 112, fill=1, stroke=0)
    c.setFillColor(HexColor("#75D8E5")); c.setFont("Helvetica-Bold", 10)
    c.drawString(40, 758, "FIELD LEDGER / FICTIONAL SERVICE OPERATIONS")
    c.setFillColor(HexColor("#FFFFFF")); c.setFont("Helvetica-Bold", 23)
    c.drawString(40, 720, title)
    c.setFillColor(GREY); c.setFont("Helvetica", 9)
    c.drawString(40, 659, f"Interactive AcroForm - template {variant} - source values read directly; no OCR")
    y = 618
    for name, label, value in fields:
        c.setFillColor(GREY); c.setFont("Helvetica-Bold", 8)
        c.drawString(40, y + 17, label.upper())
        c.acroForm.textfield(name=name, tooltip=label, x=40, y=y-8, width=532,
                            height=22, value=value, fontSize=10, fontName="Helvetica",
                            textColor=NAVY, fillColor=HexColor("#F2F7FA"),
                            borderColor=HexColor("#CADCE6"), borderWidth=0.7,
                            forceBorder=True, maxlen=1000)
        y -= 43
    c.setStrokeColor(HexColor("#CADCE6")); c.line(40, 55, 572, 55)
    c.setFillColor(GREY); c.setFont("Helvetica", 8)
    c.drawString(40, 38, "All people, organizations and records are invented. Personal demo, not client work.")
    c.drawRightString(572, 25, "FIELD LEDGER  /  01")
    c.showPage(); c.save()


def generate(destination: Path):
    if destination.exists():
        raise FileExistsError(f"Refusing to overwrite {destination}")
    expected_path = destination.parent / "expected-values.json"
    if expected_path.exists() or expected_path.is_symlink():
        raise FileExistsError(f"Refusing to overwrite {expected_path}")
    destination.mkdir(parents=True)
    schema = json.loads((ROOT / "schema.json").read_text())
    companies = ["Northstar Workshop", "Harbor Sample Works", "Juniper Demo Studio", "Cedar Fictional Lab", "Atlas Sample Depot", "Fable Equipment Co"]
    contacts = ["Avery Morgan", "Sam Rivers", "José Müller", "Robin Vale", "Jamie Chen", "Alex Rowan"]
    equipment = ["Bench drill", "Air compressor", "Water pump", "Label printer", "Power washer", "Test conveyor"]
    issues = ["Motor stops after 10 minutes", "Pressure drops during use", "Seal leaking at inlet", "Labels feed at an angle", "Intermittent power loss", "Belt tracking needs adjustment"]
    expected = {}
    for i in range(1, 25):
        ix, variant = (i-1)%6, 0 if i <= 12 else 1
        values = [f"SRV-{i:04d}", f"2026-09-{i:02d}", companies[ix], contacts[ix], f"demo{i:02d}@example.invalid", f"+1 202 555 {100+i:04d}", equipment[ix], f"EQ-{i:05d}", f"{i:09d}", issues[ix], "Inspection and maintenance", "Morning / 09:00-12:00"]
        if i in (4, 16): values[3] = ""
        if i == 6: values[9] = "  Retain two leading and trailing spaces  "
        if i == 7: values[9] = "=1+1"
        if i == 19: values[9] = "+SUM(1,2)"
        if i == 18: values[9] = "Line one; original punctuation: café / £0"
        if i == 23: values[2] = ""  # required blank: keep, flag for review
        rows = [(f["aliases"][variant], f["label"], value) for f, value in zip(schema["fields"], values) if not (i in (8,20) and f["name"] == "preferred_slot")]
        if i in (5,17): rows.append(("InternalReference", "Extra field / internal reference", f"EXTRA-{i:02d}"))
        name = f"intake-{i:02d}-template-{'A' if variant == 0 else 'B'}.pdf"
        create_pdf(destination / name, rows, "A" if variant == 0 else "B")
        expected[name] = {n:v for n,l,v in rows}
    # Three deliberately unsupported inputs, separate from the 24 intake forms.
    c = canvas.Canvas(str(destination / "reject-01-flat-document.pdf"), invariant=1)
    c.setTitle("FICTIONAL negative fixture / non-fillable")
    c.setFont("Helvetica-Bold", 18); c.drawString(50,750,"FICTIONAL DEMO / Non-fillable PDF")
    c.setFont("Helvetica", 11); c.drawString(50,720,"This text has no AcroForm fields. The extractor must quarantine it.")
    c.save()
    (destination / "reject-02-corrupt.pdf").write_bytes(b"FICTIONAL DEMO: deliberately not a PDF\n")
    conflict = [(f["aliases"][0], f["label"], f"Sample {f['name']}") for f in schema["fields"]]
    conflict.append(("ticket_number", "Conflicting service ID alias", "DIFFERENT-ID"))
    create_pdf(destination / "reject-03-schema-conflict.pdf", conflict, "CONFLICT")
    with expected_path.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(expected, indent=2, ensure_ascii=False)+"\n")
    print(f"Created 24 fictional intake forms and 3 negative PDF fixtures in {destination}")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("destination", type=Path)
    generate(p.parse_args().destination)
