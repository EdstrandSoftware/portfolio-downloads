def polish_p(t, start, dur=0.7):
    return progress(t, start, dur)

def polish_card(c, x, y, w, h):
    rect(c, x + 3, y + 4, w, h, '#d5d0ca')
    rect(c, x, y, w, h, 'paper', 'edge')

def polish_arrow(c, x1, y1, x2, y2, p):
    if p <= 0.01:
        return
    def f():
        arrow(c, x1, y1, mix(x1, x2, p), mix(y1, y2, p), 'lavender', 4)
    alpha(c, clamp(p * 3), f)

from art import *
PROJECT = 'Field Ledger'
DURATIONS = [10, 14, 12, 12, 16, 14, 12, 12, 16, 12, 14]
TITLES = ['Fillable PDFs to a reviewable workbook.', 'Reads stored form text.', 'Two field names. One agreed column.', 'Run into a new output folder.', '27 input PDFs. 27 record rows.', 'Stored values stay intact.', 'Missing company. Still blank.', 'Three files need separate attention.', 'Change the rule. See the review impact.', 'Review before using the workbook.', 'Try the included example.']
SUBTITLES=['For service-intake teams · Local Python command-line tool', 'Known fillable text fields · No OCR, scans or flattened forms', 'A person defines the mapping; the tool does not guess.', 'Example command · Run from pdf-extraction/toolproject/', '23 extracted + 1 needs review + 3 quarantined', 'Actual PDF details and saved workbook values for intake 03', 'Required company in intake 23 needs human review', 'Originals remain unchanged; quarantine holds inspection copies', 'Practice request: make contact name required', 'A person confirms the mapping and missing details', 'Start with the companion source ZIP and WORKFLOW.md']
MODES = ['ILLUSTRATED EXPLANATION', 'ACTUAL PDF + DIAGRAM', 'ILLUSTRATED EXPLANATION', 'EXAMPLE COMMAND', 'SAVED-RUN EXCERPT + DIAGRAM', 'ACTUAL PDF + DIAGRAM', 'ILLUSTRATED EXPLANATION', 'ILLUSTRATED EXPLANATION', 'ILLUSTRATED EXPLANATION', 'ILLUSTRATED EXPLANATION', 'ILLUSTRATED EXPLANATION']

from art import *

def _in(t, s=1.2, d=0.8):
    return ease(progress(t, s, d))

def draw_0(c, t):
    p = _in(t, 1.2, 0.8)
    text(c, "Known forms in. Reviewable records out.", 80, 300, 36, bold=True)
    text(c, "Preserve source text.", 80, 360, 34)
    text(c, "Flag what a person must review.", 80, 405, 34, 'coral', True)
    paper(c, 80, 470, 380, 240)
    text(c, "Fillable PDFs", 270, 600, 32, align='center')
    paper(c, 1140, 470, 380, 240)
    text(c, "Excel rows", 1330, 600, 32, align='center')
    a = clamp(p)
    arrow(c, 480, 590, 480 + 640 * a, 590, 'lavender', 4)
    alpha(c, p, lambda: pill(c, "local run", 700, 540, 220, 'coral'))
    for i in range(3):
        rect(c, 1170, 500 + i * 22, 320, 16, 'oyster', 'edge')
    for i in range(3):
        line(c, 110, 500 + i * 22, 430, 500 + i * 22, 'edge', 3)

def draw_1(c, t):
    p = _in(t, 1.2, 1.0)
    paper(c, 80, 335, 400, 417)
    image(c, "input-form.png", 125, 350, 286, 370)
    text(c, "Actual PDF03 render", 280, 740, 26, 'gray', align='center')
    text(c, "Stored field values (PDF03)", 560, 350, 32, bold=True)
    rows = [("ServiceID", "SRV-0003"), ("ContactName", "José Müller"), ("SerialNumber", "000000003")]
    for i, (k, v) in enumerate(rows):
        q = ease(progress(t, 1.8 + i * 0.5, 0.7))
        y = 400 + i * 70
        alpha(c, q, lambda k=k, v=v, y=y: (
            paper(c, 560, y, 600, 56),
            text(c, k, 580, y + 38, 28, 'gray', mono=True),
            text(c, v, 800, y + 38, 30, mono=True)))
    for i in range(3):
        arrow(c, 430, 480, 550, 428 + i * 70, 'lavender', 3)
    text(c, "Known text-only fillable forms work.", 560, 660, 32)
    text(c, "Scans and flattened PDFs are unsupported.", 560, 705, 32, 'coral')

def draw_2(c, t):
    text(c, "A person writes the mapping rules in schema.json", 80, 300, 32, bold=True)
    for i, n in enumerate(["ServiceID", "ticket_number"]):
        y = 330 + i * 100
        def f(n=n, y=y):
            polish_card(c, 80, y, 380, 72)
            text(c, n, 270, y + 47, 30, mono=True, align='center')
        alpha(c, polish_p(t, 0.5 + i * 0.5, 0.7), f)

    def sch():
        polish_card(c, 560, 330, 360, 172)
        text(c, "schema.json", 580, 380, 30, bold=True, mono=True)
        text(c, "written by a person", 580, 424, 26, 'gray')
        text(c, "exact aliases only", 580, 462, 26, 'gray')
    alpha(c, polish_p(t, 1.6, 0.7), sch)

    polish_arrow(c, 462, 366, 552, 380, polish_p(t, 2.1, 0.8))
    polish_arrow(c, 462, 466, 552, 452, polish_p(t, 2.5, 0.8))
    polish_arrow(c, 924, 416, 1052, 416, polish_p(t, 3.1, 0.8))

    def dst():
        polish_card(c, 1060, 350, 460, 132)
        text(c, "canonical column", 1084, 392, 26, 'gray')
        text(c, "service_id", 1084, 446, 34, 'coral', True, True)
    alpha(c, polish_p(t, 3.6, 0.7), dst)
    alpha(c, polish_p(t, 4.2, 0.6), lambda: outline(c, 1060, 350, 460, 132))

    def info():
        polish_card(c, 80, 550, 1440, 170)
        text(c, "The tool does not guess: only listed names match.", 108, 600, 30, bold=True)
        text(c, "ServiceID and ticket_number → service_id;  ContactName and requester → contact_name", 108, 646, 28)
        text(c, "12 mapped columns in all.", 108, 692, 28, 'gray')
    alpha(c, polish_p(t, 4.8, 0.7), info)


def draw_3(c, t):
    def s1():
        polish_card(c, 80, 270, 1440, 110)
        text(c, "1 · ONE TIME", 108, 306, 26, 'gray', mono=True)
        text(c, "Set up Python 3.10+ as written in root WORKFLOW.md", 108, 352, 30, bold=True)
    alpha(c, polish_p(t, 0.5, 0.7), s1)

    def s2():
        polish_card(c, 80, 396, 1440, 124)
        text(c, "2 · RUN FROM toolproject/ · USE A FRESH OUTPUT FOLDER (existing = exit 1)", 108, 432, 26, 'gray', mono=True)
        text(c, ".venv/bin/python -m src.extractor demo/inputs outputs/my-demo-run", 108, 488, 28, mono=True)
    alpha(c, polish_p(t, 1.6, 0.7), s2)

    def s3a():
        polish_card(c, 80, 536, 700, 184)
        text(c, "Exit code 2", 108, 586, 32, 'coral', True)
        text(c, "Completed, but some records", 108, 632, 28)
        text(c, "need review.", 108, 672, 28)
    alpha(c, polish_p(t, 2.8, 0.7), s3a)

    def s3b():
        polish_card(c, 820, 536, 700, 184)
        text(c, "COMPLETE.json", 848, 586, 32, bold=True, mono=True)
        text(c, "Completion receipt in the new folder.", 848, 632, 28)
        text(c, "Check it before using outputs.", 848, 672, 28)
    alpha(c, polish_p(t, 3.4, 0.7), s3b)


from art import *

def _title(c, s, sub=None):
    text(c, s, 80, 300, 40, bold=True)
    if sub:
        text(c, sub, 80, 340, 32)

def _card(c, x, y, w, h, lines, hi=False, size=28):
    paper(c, x, y, w, h)
    for i, s in enumerate(lines):
        text(c, s, x + 24, y + 44 + i * 40, size, mono=(i > 0 and size < 32))
    if hi:
        outline(c, x, y, w, h)

def draw_4(c, t):
    alpha(c, polish_p(t, 0.4, 0.8), lambda: image(c, "saved-proof.png", 150, 266, 1300, 270))
    alpha(c, polish_p(t, 0.4, 0.8), lambda: text(
        c, "Actual saved-run values, typeset for readability (not app UI)", 150, 566, 26, 'gray'))

    items = [("23 extracted", 280), ("1 needs review", 320), ("3 quarantined", 310)]
    x = 80
    for i, (s, w) in enumerate(items):
        def f(s=s, w=w, x=x):
            polish_card(c, x, 584, w, 56)
            text(c, s, x + w / 2, 623, 30, bold=True, align='center')
        alpha(c, polish_p(t, 1.4 + i * 0.6, 0.6), f)
        x += w
        def g(x=x):
            text(c, "+", x + 20, 623, 30, 'gray', True, align='center')
        if i < 2: alpha(c, polish_p(t, 1.4 + i * 0.6, 0.6), g)
        x += 40

    def total(x=x):
        polish_card(c, x, 584, 360, 56)
        text(c, "= 27 Records rows", x + 180, 623, 30, 'coral', True, align='center')
    alpha(c, polish_p(t, 3.4, 0.7), total)

    alpha(c, polish_p(t, 4.4, 0.7), lambda: text(
        c, "Quarantine rows stay in Records, so it is not 23 rows.", 80, 692, 28))
    alpha(c, polish_p(t, 5.4, 0.7), lambda: text(
        c, "Check COMPLETE.json, then open extracted-records.xlsx.", 80, 738, 28, 'coral', True))


def draw_5(c, t):
    text(c, "Actual PDF 03 · selected details", 80, 284, 26, 'gray')
    text(c, "Saved workbook · selected values", 860, 284, 26, 'gray')
    rows = [("ServiceID", "service_id", "SRV-0003", (58, 242, 300, 35)),
            ("ContactName", "contact_name", "José Müller", (58, 437, 300, 35)),
            ("SerialNumber", "serial_number", "000000003", (58, 762, 300, 35))]
    for j, (source, key, value, crop) in enumerate(rows):
        y = 298 + j * 142
        polish_card(c, 80, y, 640, 134)
        text(c, source, 100, y + 32, 26, 'gray', mono=True)
        image(c, 'input-form.png', 100, y + 44, 580, 68, crop)
        polish_card(c, 860, y, 660, 134)
        text(c, key, 884, y + 36, 26, 'gray', mono=True)
        text(c, value, 884, y + 98, 34, 'plum', True, True)
        k = polish_p(t, 1.4 + j * 1.6, 0.6)
        def hi(y=y):
            outline(c, 80, y, 640, 134)
            outline(c, 860, y, 660, 134)
        alpha(c, k, hi)
        polish_arrow(c, 730, y + 67, 850, y + 67, polish_p(t, 1.6 + j * 1.6, 0.8))
    alpha(c, polish_p(t, 6.4, 0.7), lambda: text(
        c, "Values copied as stored: leading zeros kept, text unchanged.", 80, 744, 28, 'coral'))



def draw_6(c, t):
    paper(c, 80, 360, 1000, 260)
    cols = [("id", 100), ("name", 260), ("company", 520), ("status", 800)]
    for s, x in cols:
        text(c, s, x, 405, 26, 'gray', True)
    line(c, 100, 425, 1060, 425)
    row = ["SRV-0023", 'Jamie Chen', "", "needs_review"]
    for (s, x), v in zip(cols, row):
        text(c, v, x, 480, 26, mono=True)
    rect(c, 500, 450, 270, 50, fill='oyster', stroke='edge')
    text(c, "Illustrated row; Company is empty", 100, 580, 26, 'gray')
    k = ease(progress(t, 1.4, 1.0))
    alpha(c, k, lambda: outline(c, 500, 450, 270, 50))
    k = ease(progress(t, 3.0, 1.0))
    alpha(c, k, lambda: (
        text(c, "A person checks with the form owner.", 80, 680, 32, 'coral', True),
        text(c, "The tool supplies no answer.", 80, 725, 32)))

def draw_7(c, t):
    items = [("reject-01-flat-document.pdf", "flat: no fillable fields"),
             ("reject-02-corrupt.pdf", "corrupt: cannot be read"),
             ("reject-03-schema-conflict.pdf", "conflicting aliases")]
    text(c, "demo/inputs/ (originals stay)", 80, 355, 26, 'gray', True)
    text(c, "quarantine/ (unchanged copies)", 820, 355, 26, 'gray', True)
    for i, (n, r) in enumerate(items):
        y = 380 + i * 105
        paper(c, 80, y, 560, 90)
        text(c, n, 104, y + 38, 26, mono=True)
        text(c, r, 104, y + 76, 26, 'coral')
        s = 1.4 + i * 0.9
        k = ease(progress(t, s, 0.9))
        arrow(c, 650, y + 45, mix(650, 800, k), y + 45)
        alpha(c, k, lambda y=y, n=n, k=k: translate(c, -180*(1-k), 0, lambda: (paper(c, 820, y, 640, 90), text(c, n + " (copy)", 844, y + 55, 26, mono=True))))
    k = ease(progress(t, 4.6, 0.8))
    alpha(c, k, lambda: text(c, "Quarantine: copies set aside for inspection.", 80, 735, 28, 'plum'))


from art import *

def _row(c, label, val, x, y, w=1300, hl=False):
    rect(c, x, y, w, 52, 'paper', 'edge')
    text(c, label, x + 20, y + 36, 26, 'gray', mono=True)
    text(c, val, x + 360, y + 36, 26, 'plum', mono=True)
    if hl:
        outline(c, x, y, w, 52)

def draw_8(c,t):
    text(c,'Edit a schema copy, then run the extractor again.',80,305,34)
    changed=t>=2;finished=t>=6.2
    paper(c,80,350,620,350);text(c,'contact_name',110,405,30,'gray',mono=True)
    text(c,'required: true' if changed else 'required: false',110,487,34,'coral' if changed else 'plum',True,True)
    outline(c,100,436,555,82,'coral' if changed else 'edge',3)
    text(c,'Rule edited: name is required.' if changed else 'Current rule: name is optional.',110,580,28,'gray')
    if t>=4:
        text(c,'Rerun',755,470,26,'coral',True,align='center')
        arrow(c,710,505,mix(710,790,progress(t,4,1.4)),505)
    paper(c,810,350,710,350);text(c,'Review status after the run',838,405,32,'plum',True)
    for j,name in enumerate(['intake 04','intake 16']):
        text(c,name,838,470+j*55,30,mono=True)
        pill(c,'needs review' if finished else 'extracted',1085,437+j*55,245,'coral' if finished else 'plum')
    text(c,'extracted / review / quarantine',838,586,26,'gray')
    text(c,'21 / 3 / 3' if finished else '23 / 1 / 3',838,650,42,'plum',True,True)
    text(c,'Missing names stay blank. Original PDFs stay unchanged.',80,747,29,'gray')





def draw_9(c, t):
    alpha(c, polish_p(t, 0.3, 0.5), lambda: text(
        c, "Open extracted-records.xlsx, then check three places", 80, 300, 30, bold=True))
    cards = [("Check 1", "RunSummary", ["Counts and", "completion status"]),
             ("Check 2", "Validation", ["Warnings and", "missing values"]),
             ("Check 3", "Records + RawFields", ["Compare with", "the source PDF"])]
    for i, (tag, name, det) in enumerate(cards):
        x = 80 + i * 490
        def f(x=x, tag=tag, name=name, det=det):
            polish_card(c, x, 330, 460, 200)
            text(c, tag, x + 24, 372, 26, 'gray', mono=True)
            text(c, name, x + 24, 418, 30, bold=True)
            text(c, det[0], x + 24, 458, 26)
            text(c, det[1], x + 24, 498, 26)
        alpha(c, polish_p(t, 0.6 + i * 0.5, 0.6), f)
        if i < 2:
            polish_arrow(c, x + 464, 430, x + 486, 430, polish_p(t, 0.9 + i * 0.5, 0.5))

    def bottom():
        polish_card(c, 80, 556, 1440, 190)
        text(c, "You confirm the mapping and any missing details.", 108, 600, 28)
        text(c, "Wrong? Correct the input copies or config, then rerun.", 108, 640, 28)
        text(c, "Editing Excel does not update the PDFs or the audit.", 108, 680, 28, 'coral', True)
        text(c, "Check source values before use—even extracted rows.", 108, 720, 26, 'gray')
    alpha(c, polish_p(t, 2.0, 0.5), bottom)


def draw_10(c, t):
    paper(c,80,274,1440,95,spine='coral')
    text(c,'COMPANION SOURCE ZIP',110,309,26,'gray',mono=True)
    text(c,'field-ledger-motion-source.zip',110,351,34,'plum',True,True)
    steps=[('1','Extract the ZIP.','The runnable example is in pdf-extraction/toolproject/.'),
           ('2','Start with WORKFLOW.md.','At the package root: Python 3.10+ setup and verified steps.'),
           ('3','Run into a new output folder.','Use the fresh-folder commands in that document.')]
    for j,(num,title,detail) in enumerate(steps):
        y=395+j*113;q=progress(t,.4+j*.7,.7)
        def draw_step(y=y,num=num,title=title,detail=detail):
            paper(c,80,y,1440,96,spine='plum');text(c,num,110,y+59,42,'coral',True)
            text(c,title,180,y+39,34,'plum',True);text(c,detail,180,y+78,28,'gray')
        alpha(c,q,draw_step)


SCENES=[draw_0,draw_1,draw_2,draw_3,draw_4,draw_5,draw_6,draw_7,draw_8,draw_9,draw_10]
def draw(c,i,t):
    SCENES[i](c,t)
