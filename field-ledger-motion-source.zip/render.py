"""Headless deterministic film renderer. Editable scene source accompanies this renderer.
python3 render.py PROJECT --output PROJECT/output/film.mp4
python3 render.py PROJECT --frame 54 --png PROJECT/qa/frame54.png
"""
import sys,argparse,importlib.util,subprocess,time,json,hashlib
from pathlib import Path
import cairo
import art
ROOT=Path(__file__).resolve().parent
def load(project):
 p=ROOT/project; art.ASSETS=p/'assets';spec=importlib.util.spec_from_file_location('scenes',p/'scenes.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);assert len(m.DURATIONS)==len(m.TITLES)==len(m.SUBTITLES)==len(m.MODES)==11;return p,m
def frame(m,sec):
 idx=0;local=sec
 for j,d in enumerate(m.DURATIONS):
  if local<d or j==len(m.DURATIONS)-1:idx=j;break
  local-=d
 s=cairo.ImageSurface(cairo.FORMAT_RGB24,1600,900);c=cairo.Context(s)
 art.TEXT_LOG.clear();art.frame(c,m.PROJECT,idx,m.TITLES[idx],m.SUBTITLES[idx],m.MODES[idx])
 # Complete headers stay intact. Different short body entrances end before reading/action holds.
 entrances=['cut','fade','cut','rise','cut','fade','cut','rise','cut','fade','cut']
 enter=art.progress(local,0,.4) if idx else 1
 if entrances[idx]=='cut':m.draw(c,idx,local)
 else:
  c.push_group();c.save()
  if entrances[idx]=='rise':c.translate(0,12*(1-enter))
  m.draw(c,idx,local);c.restore();pat=c.pop_group();c.set_source(pat);c.paint_with_alpha(enter)

 s.flush();return s,idx,local
def main():
 a=argparse.ArgumentParser();a.add_argument('project',choices=['pdf-extraction','api-transfer']);a.add_argument('--output');a.add_argument('--frame',type=float);a.add_argument('--png');a.add_argument('--fps',type=int,default=30);a.add_argument('--start',type=float,default=0);a.add_argument('--end',type=float);a.add_argument('--crf',default='19');args=a.parse_args()
 p,m=load(args.project)
 if args.frame is not None:
  s,i,t=frame(m,args.frame);out=Path(args.png);out.parent.mkdir(parents=True,exist_ok=True);s.write_to_png(str(out));print(json.dumps({'frame':args.frame,'scene':i+1,'local_time':t,'file':str(out)}));return
 out=Path(args.output or p/'output/film.mp4');out.parent.mkdir(parents=True,exist_ok=True);duration=sum(m.DURATIONS);end=args.end if args.end is not None else duration;n=round((end-args.start)*args.fps);assert n>0
 command=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','bgr0','-video_size','1600x900','-framerate',str(args.fps),'-i','-','-an','-c:v','libx264','-preset','fast','-crf',args.crf,'-pix_fmt','yuv420p','-movflags','+faststart',str(out)]
 started=time.monotonic();f=subprocess.Popen(command,stdin=subprocess.PIPE);progress=p/'output/render-progress.json';progress.parent.mkdir(parents=True,exist_ok=True)
 try:
  for k in range(n):
   sec=args.start+k/args.fps;s,i,t=frame(m,sec);f.stdin.write(s.get_data())
   if k%150==0:progress.write_text(json.dumps({'frame':k,'total_frames':n,'seconds':sec,'scene':i+1,'elapsed':round(time.monotonic()-started,2)}))
  f.stdin.close();rc=f.wait();assert rc==0
 finally:
  if f.poll() is None:f.terminate();f.wait()
 info={'file':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'duration':end-args.start,'fps':args.fps,'frames':n,'elapsed_seconds':round(time.monotonic()-started,3),'silent':True,'scene_source_sha256':hashlib.sha256((p/'scenes.py').read_bytes()).hexdigest(),'shared_art_sha256':hashlib.sha256((ROOT/'art.py').read_bytes()).hexdigest(),'renderer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 (out.parent/(out.stem+'-render.json')).write_text(json.dumps(info,indent=2));progress.write_text(json.dumps({'state':'complete',**info},indent=2));print(json.dumps(info))
if __name__=='__main__':main()
