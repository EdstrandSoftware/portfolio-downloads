"""Reproduce the evidence using the CLI subprocess and real loopback HTTP servers."""
import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from relay.core import digest, utc_now, RelayError
from relay.outputs import output_directory
from relay.mock_api import DEMO_TOKEN, DemoCluster


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    parser.add_argument("--overwrite", action="store_true", help="Replace named evidence files in an existing folder")
    args = parser.parse_args()
    try:
        output = output_directory(args.output, ROOT, "demo", args.overwrite)
    except RelayError as exc:
        parser.error(exc.code)
    started = utc_now()
    phases, transcript = [], []
    with tempfile.TemporaryDirectory(prefix="csv-relay-demo-") as temp:
        work = Path(temp)
        env = os.environ.copy()
        env["RELAY_SOURCE_TOKEN"] = DEMO_TOKEN
        def run_phase(name, cluster, flags=(), expected_exit=0, ledger=None):
            log_path = output / f"{name}.jsonl"
            log_path.write_text("", encoding="utf-8")
            report_path = output / f"{name}.json"
            before = len(cluster.state.receipts())
            cmd = [sys.executable, "-m", "relay", "--source", cluster.source,
                   "--receiver", cluster.receiver, "--ledger", str(ledger or work / "ledger.sqlite"),
                   "--log", str(log_path), "--report", str(report_path),
                   *(["--overwrite-report"] if args.overwrite else []), *flags]
            completed = subprocess.run(cmd, cwd=ROOT, env=env, capture_output=True, text=True, timeout=30)
            transcript.extend([f"PHASE: {name}", "$ " + " ".join(cmd), completed.stdout.rstrip(),
                               f"exit_code={completed.returncode}", completed.stderr.rstrip(), ""])
            if completed.returncode != expected_exit:
                raise AssertionError(f"{name}: unexpected exit {completed.returncode}: {completed.stderr}")
            result = json.loads(report_path.read_text())
            phase = {"name": name, "exit_code": completed.returncode, "new_receipts": len(cluster.state.receipts()) - before,
                     "total_receipts": len(cluster.state.receipts()),
                     **{k: result[k] for k in ("succeeded", "failed", "skipped", "would_send", "ok")}}
            phases.append(phase)
            return result
        with DemoCluster(work / "dry-server", faults=False) as dry:
            run_phase("01-dry-run", dry, ["--dry-run"], ledger=work / "dry-ledger.sqlite")
            assert not (work / "dry-ledger.sqlite").exists()
            assert len(dry.state.receipts()) == 0
            dry_events = dry.state.events.copy()
        with DemoCluster(work / "server", faults=True) as cluster:
            first = run_phase("02-injected-failures", cluster, expected_exit=1)
            assert (first["succeeded"], first["failed"]) == (6, 2)
            cluster.state.recovered = True  # Remove the two deliberate receiver faults.
            recovery = run_phase("03-failed-only-recovery", cluster, ["--retry-failed"])
            assert (recovery["succeeded"], recovery["skipped"]) == (2, 6)
            posts_before_rerun = sum(v for (op, _), v in cluster.state.calls.items() if op == "send")
            rerun = run_phase("04-idempotent-rerun", cluster)
            posts_after_rerun = sum(v for (op, _), v in cluster.state.calls.items() if op == "send")
            assert (rerun["succeeded"], rerun["skipped"]) == (0, 8)
            assert posts_before_rerun == posts_after_rerun
            receipts = cluster.state.receipts()
            integrity = [{"batch_id": row["batch_id"], "bytes": len(row["body"]), "sha256": row["sha256"],
                          "receipt_id": row["receipt_id"],
                          "byte_equal_to_fixture": row["body"] == cluster.state.batches[row["batch_id"]]}
                         for row in receipts]
            assert len(receipts) == 8 and all(row["byte_equal_to_fixture"] for row in integrity)
            events = cluster.state.events.copy()
            lost = [e for e in events if e["operation"] == "send" and e["batch_id"] == "parts-005"]
            assert len(lost) == 2 and lost[0]["receipt_id"] == lost[1]["receipt_id"]
            assert lost[0]["idempotency_key"] == lost[1]["idempotency_key"] and lost[1]["replayed"]
            proof = {"batch_id": "parts-005", "attempts": lost,
                     "same_idempotency_key": lost[0]["idempotency_key"] == lost[1]["idempotency_key"],
                     "same_receipt": lost[0]["receipt_id"] == lost[1]["receipt_id"],
                     "stored_receipts_for_batch": sum(r["batch_id"] == "parts-005" for r in receipts)}
        shutil.copy2(work / "ledger.sqlite", output / "audit-ledger.sqlite")
        shutil.copy2(work / "server" / "receiver.sqlite", output / "receiver-receipts.sqlite")
    write_json(output / "integrity-results.json", integrity)
    write_json(output / "ambiguous-commit-proof.json", proof)
    write_json(output / "server-events.json", {"dry_run": dry_events, "transfer_recovery_rerun": events})
    summary = {"title": "CSV relay: real recorded local test run", "started_at": started, "finished_at": utc_now(),
               "python": platform.python_version(), "platform": platform.system(), "fictional_data": True,
               "network_scope": "Two real HTTP APIs, both bound to 127.0.0.1 only",
               "phases": phases, "fixture_batches": 8, "fixture_rows": 24,
               "verified_identical_batches": len(integrity), "total_receiver_receipts": len(receipts),
               "rerun_new_post_requests": posts_after_rerun - posts_before_rerun,
               "ambiguous_commit_replayed_same_receipt": True, "dry_run_ledger_created": False,
               "receiver_authorization_headers_seen": sum(bool(e.get("authorization_present")) for e in events),
               "production_exactly_once_claim": False}
    write_json(output / "demo-summary.json", summary)
    (output / "cli-transcript.txt").write_text("\n".join(transcript), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    print("Saved demo evidence:", output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
