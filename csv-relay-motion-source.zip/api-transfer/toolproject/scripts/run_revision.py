"""Simulated follow-up: deliver one newly arrived batch after eight completed batches."""
import argparse,json,os,shutil,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from relay.mock_api import DemoCluster,DEMO_TOKEN
from relay.core import digest,utc_now
from relay.outputs import output_directory

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--output',type=Path,default=ROOT/'runs'/'revision-practice')
 args=parser.parse_args()
 # No overwrite switch: prior revision evidence must remain intact.
 output=output_directory(args.output,ROOT,'revision',False)
 phases=[];transcript=[]
 with tempfile.TemporaryDirectory(prefix='csv-relay-revision-') as tmp:
  work=Path(tmp);env=os.environ.copy();env['RELAY_SOURCE_TOKEN']=DEMO_TOKEN
  def run(name,cluster,flags=()):
   before=cluster.state.receipts();posts_before=sum(v for (op,_),v in cluster.state.calls.items() if op=='send')
   cmd=[sys.executable,'-m','relay','--source',cluster.source,'--receiver',cluster.receiver,'--ledger',str(work/'ledger.sqlite'),'--route','fictional-parts-revision-v1','--report',str(output/f'{name}.json'),'--log',str(output/f'{name}.jsonl'),*flags]
   p=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,text=True,timeout=30)
   transcript.append({'phase':name,'command':cmd,'cwd':str(ROOT),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
   assert p.returncode==0,(name,p.stderr)
   result=json.loads((output/f'{name}.json').read_text());after=cluster.state.receipts()
   posts_after=sum(v for (op,_),v in cluster.state.calls.items() if op=='send')
   phase={'name':name,'exit_code':p.returncode,**{k:result[k] for k in ['discovered','succeeded','failed','skipped']},'new_receipts':len(after)-len(before),'total_receipts':len(after),'new_posts':posts_after-posts_before}
   phases.append(phase);return result
  with DemoCluster(work/'server',faults=False) as cluster:
   seed=run('01-original-eight',cluster);assert (seed['succeeded'],seed['skipped'])==(8,0)
   original_receipts={r['batch_id']:r['receipt_id'] for r in cluster.state.receipts()}
   new_bytes=(ROOT/'revision/parts-009.csv').read_bytes()
   cluster.state.batches['parts-009']=new_bytes  # Simulate a newly listed source batch, not a relay code change.
   retry=run('02-retry-failed-only',cluster,['--retry-failed'])
   assert (retry['succeeded'],retry['skipped'])==(0,9)
   assert next(b for b in retry['batches'] if b['id']=='parts-009')['reason']=='not_failed_or_pending'
   assert phases[-1]['new_posts']==0
   transfer=run('03-transfer-new-batch',cluster)
   assert (transfer['succeeded'],transfer['skipped'])==(1,8) and phases[-1]['new_posts']==1
   rerun=run('04-confirm-rerun',cluster)
   assert (rerun['succeeded'],rerun['skipped'])==(0,9) and phases[-1]['new_posts']==0
   receipts=cluster.state.receipts()
   assert len(receipts)==9
   integrity=[]
   for row in receipts:
    expected=new_bytes if row['batch_id']=='parts-009' else (ROOT/'fixtures'/f"{row['batch_id']}.csv").read_bytes()
    assert row['body']==expected and row['sha256']==digest(expected)
    if row['batch_id'] in original_receipts:assert row['receipt_id']==original_receipts[row['batch_id']]
    integrity.append({'batch_id':row['batch_id'],'bytes':len(expected),'sha256':digest(expected),'byte_exact':True,'receipt_id':row['receipt_id']})
   events=cluster.state.events.copy()
   assert not any(e.get('authorization_present') for e in events)
  shutil.copy2(work/'ledger.sqlite',output/'audit-ledger.sqlite')
  shutil.copy2(work/'server/receiver.sqlite',output/'receiver-receipts.sqlite')
 summary={'recorded_at':utc_now(),'fictional_data':True,'simulated_request':'Accept a newly arrived ninth batch without resending the first eight','original_batches':8,'new_batches':1,'final_receipts':9,'phases':phases,'original_receipt_ids_unchanged':True,'all_received_bytes_match':True,'receiver_authorization_headers_seen':0,'production_exactly_once_claim':False}
 for filename,value in [('revision-summary.json',summary),('integrity-results.json',integrity),('server-events.json',events),('cli-transcript.json',transcript)]:
  (output/filename).write_text(json.dumps(value,indent=2)+'\n')
 (output/'cli-transcript.txt').write_text('\n\n'.join('PHASE: '+x['phase']+'\n$ '+' '.join(x['command'])+'\nexit_code='+str(x['exit_code'])+'\n'+x['stdout']+x['stderr'] for x in transcript))
 print(json.dumps(summary,indent=2));print('Saved revision evidence:',output)
 return 0
if __name__=='__main__':raise SystemExit(main())
