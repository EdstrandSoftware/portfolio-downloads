"""Run the actual test suite and save machine-readable plus verbatim test results."""
import io
import json
import platform
import sys
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from relay.core import utc_now, RelayError
from relay.outputs import output_directory


class RecordedResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.results = []

    def addSuccess(self, test):
        super().addSuccess(test)
        self.results.append({"test": test.id(), "status": "passed"})

    def addFailure(self, test, err):
        super().addFailure(test, err)
        self.results.append({"test": test.id(), "status": "failed"})

    def addError(self, test, err):
        super().addError(test, err)
        self.results.append({"test": test.id(), "status": "error"})


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    parser.add_argument("--overwrite", action="store_true", help="Replace named evidence files in an existing folder")
    args = parser.parse_args()
    try:
        args.output = output_directory(args.output, ROOT, "tests", args.overwrite)
    except RelayError as exc:
        parser.error(exc.code)
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    stream = io.StringIO()
    started, tick = utc_now(), time.monotonic()
    result = unittest.TextTestRunner(stream=stream, verbosity=2, resultclass=RecordedResult).run(suite)
    output = stream.getvalue()
    print(output, end="")
    summary = {"started_at": started, "finished_at": utc_now(), "python": platform.python_version(),
               "platform": platform.system(), "duration_seconds": round(time.monotonic() - tick, 3),
               "tests_run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
               "skipped": len(result.skipped), "successful": result.wasSuccessful(), "tests": result.results}
    (args.output / "test-results.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    (args.output / "test-output.txt").write_text(output, encoding="utf-8")
    print("Saved test evidence:", args.output)
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
