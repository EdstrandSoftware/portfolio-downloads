"""Byte-preserving CSV relay: a deliberately loopback-only portfolio exercise."""
__version__ = "1.0.0"
