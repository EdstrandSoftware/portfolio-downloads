"""Conservative output handling for local demo files."""
from __future__ import annotations
import json
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4
from .core import RelayError


def fresh_name(prefix: str) -> str:
    return prefix + "-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "-" + uuid4().hex[:6]


def validate_outputs(ledger: Path, log: Path, report: Path, *, overwrite_report=False):
    paths = [ledger, log, report]
    for i, a in enumerate(paths):
        if a.exists() and not a.is_file():
            raise RelayError("output_path_not_file")
        for b in paths[i+1:]:
            if a.resolve() == b.resolve() or (a.exists() and b.exists() and a.samefile(b)):
                raise RelayError("output_paths_collide")
    for sidecar in (Path(str(ledger) + suffix) for suffix in ("-journal", "-wal", "-shm")):
        for target in (log, report):
            if target.resolve() == sidecar.resolve() or (target.exists() and sidecar.exists() and target.samefile(sidecar)):
                raise RelayError("output_collides_with_sqlite_sidecar")
    if report.exists() and not overwrite_report:
        raise RelayError("report_exists_use_overwrite_report")
    # Logs append on repeated runs. Refuse to append JSON to arbitrary existing files.
    if log.exists():
        try:
            with log.open(encoding="utf-8") as stream:
                for line in stream:
                    if line.strip():
                        event = json.loads(line)
                        if not isinstance(event, dict) or not isinstance(event.get("event"), str):
                            raise ValueError
        except (ValueError, UnicodeError):
            raise RelayError("existing_log_is_not_event_jsonl") from None


def output_directory(requested: Path | None, root: Path, prefix: str, overwrite: bool) -> Path:
    output = (requested or root / "runs" / fresh_name(prefix)).resolve()
    if output.exists() and (not output.is_dir() or (any(output.iterdir()) and not overwrite)):
        raise RelayError("output_directory_not_empty_use_overwrite")
    output.mkdir(parents=True, exist_ok=True)
    return output
