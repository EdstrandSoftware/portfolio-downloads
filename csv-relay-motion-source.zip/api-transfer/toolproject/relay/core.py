"""Small sequential relay, durable ledger, and bounded HTTP retries (stdlib only)."""
from __future__ import annotations

import hashlib
import http.client
import json
import math
import re
import socket
import sqlite3
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Callable

ID = re.compile(r"^[A-Za-z0-9_-]{1,80}$")
SHA = re.compile(r"^[0-9a-f]{64}$")
MAX_BYTES = 5 * 1024 * 1024
MAX_BATCHES = 1000


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def stable_key(route: str, batch_id: str, sha256: str) -> str:
    """Logical route is stable across server restarts; do not reuse it for a new receiver."""
    return digest(json.dumps(["csv-relay-v1", route, batch_id, sha256],
                             separators=(",", ":")).encode())


class RelayError(Exception):
    """Only controlled, secret-free codes appear in user reports."""
    def __init__(self, code: str, *, status: int | None = None, attempts: int = 0):
        super().__init__(code)
        self.code, self.status, self.attempts = code, status, attempts


class Audit:
    """Structured allowlisted fields. Never logs tokens, URLs, bodies, or exception text."""
    ALLOWED = {"operation", "batch_id", "attempt", "status", "code", "delay_seconds",
               "sha256", "bytes", "receipt_id", "replayed", "mode", "count", "page",
               "idempotency_key", "route"}

    def __init__(self, path: Path | None = None):
        self.path, self.events = path, []
        if path:
            path.parent.mkdir(parents=True, exist_ok=True)

    def emit(self, event: str, **fields):
        record = {"at": utc_now(), "event": event,
                  **{k: v for k, v in fields.items() if k in self.ALLOWED}}
        self.events.append(record)
        if self.path:
            with self.path.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(record, sort_keys=True) + "\n")


def local_base(url: str) -> str:
    """No DNS, proxies, redirects, external ports, or accidental production access."""
    try:
        p = urllib.parse.urlsplit(url)
        port = p.port
    except ValueError:
        raise RelayError("invalid_local_url") from None
    if (p.scheme != "http" or p.hostname != "127.0.0.1" or port is None
            or not 1 <= port <= 65535 or p.username or p.password
            or p.path not in ("", "/") or p.query or p.fragment):
        raise RelayError("only_literal_127_0_0_1_http_base_allowed")
    return f"http://127.0.0.1:{port}"


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


@dataclass(frozen=True)
class RetryPolicy:
    max_attempts: int = 3
    timeout: float = 2.0
    base_delay: float = 0.1
    max_delay: float = 2.0

    def __post_init__(self):
        if not 1 <= self.max_attempts <= 10:
            raise ValueError("max_attempts must be between 1 and 10")
        if not all(math.isfinite(v) for v in (self.timeout, self.base_delay, self.max_delay)):
            raise ValueError("retry values must be finite")
        if not (0 < self.timeout <= 30 and 0 <= self.base_delay <= self.max_delay <= 30):
            raise ValueError("invalid retry budget")


def retry_delay(header: str | None, attempt: int, policy: RetryPolicy) -> float:
    delay = min(policy.max_delay, policy.base_delay * (2 ** (attempt - 1)))
    if header is not None:
        try:
            if re.fullmatch(r"\d+", header.strip()):
                specified = float(header)
            else:
                date = parsedate_to_datetime(header)
                if date.tzinfo is None:
                    date = date.replace(tzinfo=timezone.utc)
                specified = max(0.0, (date - datetime.now(timezone.utc)).total_seconds())
            if not math.isfinite(specified) or specified > policy.max_delay:
                raise RelayError("retry_after_exceeds_budget")
            delay = max(delay, specified)
        except (ValueError, TypeError, OverflowError):
            # An invalid server hint falls back to bounded exponential delay.
            pass
    return delay


class HttpClient:
    TRANSIENT = {429, 502, 503, 504}

    def __init__(self, audit: Audit, policy: RetryPolicy | None = None,
                 sleep: Callable[[float], None] = time.sleep):
        self.audit, self.policy, self.sleep = audit, policy or RetryPolicy(), sleep
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())

    def request(self, method: str, base: str, path: str, *, operation: str,
                batch_id: str | None = None, headers: dict | None = None,
                body: bytes | None = None, on_attempt: Callable[[], None] | None = None):
        base = local_base(base)
        if not path.startswith("/") or path.startswith("//"):
            raise RelayError("invalid_request_path")
        for attempt in range(1, self.policy.max_attempts + 1):
            if on_attempt:
                on_attempt()
            self.audit.emit("http_attempt", operation=operation, batch_id=batch_id, attempt=attempt)
            req = urllib.request.Request(base + path, data=body, headers=headers or {}, method=method)
            status, hint = None, None
            try:
                with self.opener.open(req, timeout=self.policy.timeout) as response:
                    status = response.status
                    payload = response.read(MAX_BYTES + 1)
                    if len(payload) > MAX_BYTES:
                        raise RelayError("response_too_large", status=status, attempts=attempt)
                    self.audit.emit("http_response", operation=operation, batch_id=batch_id,
                                    attempt=attempt, status=status)
                    return status, response.headers, payload
            except urllib.error.HTTPError as exc:
                status, hint = exc.code, exc.headers.get("Retry-After")
                exc.close()  # Do not read or log an untrusted error body.
                code = f"http_{status}"
                retryable = status in self.TRANSIENT
            except (urllib.error.URLError, socket.timeout, ConnectionError,
                    http.client.HTTPException, OSError):
                code, retryable = "transport_error", True
            if not retryable or attempt == self.policy.max_attempts:
                self.audit.emit("request_failed", operation=operation, batch_id=batch_id,
                                attempt=attempt, status=status, code=code)
                raise RelayError(code, status=status, attempts=attempt)
            try:
                delay = retry_delay(hint, attempt, self.policy)
            except RelayError as exc:
                self.audit.emit("request_failed", operation=operation, batch_id=batch_id,
                                attempt=attempt, status=status, code=exc.code)
                raise RelayError(exc.code, status=status, attempts=attempt) from None
            self.audit.emit("retry_scheduled", operation=operation, batch_id=batch_id,
                            attempt=attempt, status=status, code=code, delay_seconds=delay)
            self.sleep(delay)
        raise AssertionError("unreachable")


def object_json(data: bytes) -> dict:
    try:
        value = json.loads(data)
        if not isinstance(value, dict):
            raise ValueError
        return value
    except (ValueError, UnicodeDecodeError):
        raise RelayError("invalid_json_object") from None


class Ledger:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path)
        self.db.execute("""CREATE TABLE IF NOT EXISTS transfers (
            route TEXT NOT NULL, batch_id TEXT NOT NULL, sha256 TEXT NOT NULL,
            idempotency_key TEXT NOT NULL, state TEXT NOT NULL,
            post_attempts INTEGER NOT NULL DEFAULT 0, receipt_id TEXT,
            error_code TEXT, updated_at TEXT NOT NULL, PRIMARY KEY(route, batch_id))""")
        self.db.commit()

    def get(self, route: str, batch_id: str) -> dict | None:
        self.db.row_factory = sqlite3.Row
        row = self.db.execute("SELECT * FROM transfers WHERE route=? AND batch_id=?",
                              (route, batch_id)).fetchone()
        return dict(row) if row else None

    def prepare(self, route: str, batch_id: str, sha: str, key: str):
        old = self.get(route, batch_id)
        if old and old["sha256"] != sha:
            raise RelayError("batch_identity_changed")
        self.db.execute("""INSERT INTO transfers
            (route,batch_id,sha256,idempotency_key,state,updated_at) VALUES (?,?,?,?,?,?)
            ON CONFLICT(route,batch_id) DO UPDATE SET state='pending',error_code=NULL,updated_at=excluded.updated_at""",
            (route, batch_id, sha, key, "pending", utc_now()))
        self.db.commit()

    def attempt(self, route: str, batch_id: str):
        self.db.execute("UPDATE transfers SET post_attempts=post_attempts+1,updated_at=? WHERE route=? AND batch_id=?",
                        (utc_now(), route, batch_id))
        self.db.commit()

    def finish(self, route: str, batch_id: str, *, receipt: str | None = None,
               error: str | None = None):
        self.db.execute("""UPDATE transfers SET state=?,receipt_id=?,error_code=?,updated_at=?
                           WHERE route=? AND batch_id=?""",
                        ("failed" if error else "succeeded", receipt, error, utc_now(), route, batch_id))
        self.db.commit()

    def close(self):
        self.db.close()


class Relay:
    def __init__(self, source: str, receiver: str, token: str, *, ledger_path: Path,
                 route: str = "fictional-parts-v1", audit: Audit | None = None,
                 policy: RetryPolicy | None = None):
        self.source, self.receiver = local_base(source), local_base(receiver)
        if not token or any(c in token for c in "\r\n"):
            raise RelayError("missing_or_invalid_source_token")
        if not ID.fullmatch(route):
            raise RelayError("invalid_route")
        self.token, self.ledger_path, self.route = token, ledger_path, route
        self.audit = audit or Audit()
        self.http = HttpClient(self.audit, policy)

    def discover(self) -> list[dict]:
        batches, seen_ids, seen_cursors = [], set(), set()
        cursor = "0"
        for page in range(1, MAX_BATCHES + 1):
            if cursor in seen_cursors:
                raise RelayError("pagination_cycle")
            seen_cursors.add(cursor)
            _, _, body = self.http.request("GET", self.source,
                "/batches?cursor=" + urllib.parse.quote(cursor, safe=""), operation="list",
                headers={"Authorization": "Bearer " + self.token})
            data = object_json(body)
            items = data.get("items")
            if not isinstance(items, list):
                raise RelayError("invalid_manifest")
            for item in items:
                if (not isinstance(item, dict) or not isinstance(item.get("id"), str)
                    or not ID.fullmatch(item["id"]) or not isinstance(item.get("sha256"), str)
                    or not SHA.fullmatch(item["sha256"]) or type(item.get("bytes")) is not int
                    or not 0 <= item["bytes"] <= MAX_BYTES):
                    raise RelayError("invalid_manifest")
                if item["id"] in seen_ids:
                    raise RelayError("duplicate_batch_id")
                seen_ids.add(item["id"])
                batches.append({k: item[k] for k in ("id", "sha256", "bytes")})
                if len(batches) > MAX_BATCHES:
                    raise RelayError("too_many_batches")
            self.audit.emit("page_discovered", page=page, count=len(items))
            cursor = data.get("next_cursor")
            if cursor is None:
                return batches
            if not isinstance(cursor, str) or len(cursor) > 128:
                raise RelayError("invalid_cursor")
        raise RelayError("too_many_pages")

    def run(self, *, dry_run: bool = False, retry_failed: bool = False) -> dict:
        if dry_run and retry_failed:
            raise RelayError("dry_run_cannot_retry_failed")
        result = {"started_at": utc_now(), "route": self.route,
                  "mode": "dry_run" if dry_run else "retry_failed" if retry_failed else "transfer",
                  "discovered": 0, "succeeded": 0, "failed": 0, "skipped": 0,
                  "would_send": 0, "aborted": False, "batches": []}
        ledger = None
        try:
            batches = self.discover()
            result["discovered"] = len(batches)
            if not dry_run:
                ledger = Ledger(self.ledger_path)
            for batch in batches:
                bid, sha = batch["id"], batch["sha256"]
                row = ledger.get(self.route, bid) if ledger else None
                key = stable_key(self.route, bid, sha)
                record = {"id": bid, "sha256": sha, "bytes": batch["bytes"], "idempotency_key": key}
                prepared = False
                try:
                    if row and row["sha256"] != sha:
                        raise RelayError("batch_identity_changed")
                    if row and row["state"] == "succeeded":
                        record.update(state="skipped", reason="already_succeeded", receipt_id=row["receipt_id"])
                        result["skipped"] += 1
                    elif retry_failed and (not row or row["state"] not in ("failed", "pending")):
                        record.update(state="skipped", reason="not_failed_or_pending")
                        result["skipped"] += 1
                    else:
                        if ledger:
                            ledger.prepare(self.route, bid, sha, key)
                            prepared = True
                        _, _, csv = self.http.request("GET", self.source, "/batches/" + bid,
                            operation="fetch", batch_id=bid,
                            headers={"Authorization": "Bearer " + self.token})
                        if len(csv) != batch["bytes"] or digest(csv) != sha:
                            raise RelayError("source_integrity_mismatch")
                        self.audit.emit("integrity_verified", batch_id=bid, bytes=len(csv), sha256=sha)
                        if dry_run:
                            record["state"] = "would_send"
                            result["would_send"] += 1
                        else:
                            # Only safe because THIS receiver contract atomically deduplicates keys.
                            _, _, reply = self.http.request("POST", self.receiver, "/ingest",
                                operation="send", batch_id=bid, body=csv,
                                headers={"Content-Type": "text/csv", "X-Batch-ID": bid,
                                         "X-Content-SHA256": sha, "Idempotency-Key": key},
                                on_attempt=lambda: ledger.attempt(self.route, bid))
                            receipt = object_json(reply)
                            if (receipt.get("sha256") != sha or receipt.get("bytes") != len(csv)
                                or receipt.get("batch_id") != bid
                                or receipt.get("idempotency_key") != key
                                or not isinstance(receipt.get("receipt_id"), str)
                                or not ID.fullmatch(receipt["receipt_id"])
                                or type(receipt.get("replayed")) is not bool):
                                raise RelayError("receiver_receipt_mismatch")
                            ledger.finish(self.route, bid, receipt=receipt["receipt_id"])
                            record.update(state="succeeded", receipt_id=receipt["receipt_id"],
                                          replayed=receipt["replayed"])
                            result["succeeded"] += 1
                            self.audit.emit("delivered", batch_id=bid, receipt_id=receipt["receipt_id"],
                                            replayed=receipt["replayed"], sha256=sha, idempotency_key=key)
                except RelayError as exc:
                    if prepared:
                        ledger.finish(self.route, bid, error=exc.code)
                    record.update(state="failed", error=exc.code)
                    result["failed"] += 1
                    self.audit.emit("batch_failed", batch_id=bid, code=exc.code, status=exc.status)
                    if exc.status in (401, 403):
                        result["aborted"] = True
                result["batches"].append(record)
                if result["aborted"]:
                    break
        except RelayError as exc:
            result.update(aborted=True, error=exc.code)
            self.audit.emit("run_aborted", code=exc.code, status=exc.status)
        finally:
            if ledger:
                ledger.close()
        result["finished_at"] = utc_now()
        result["ok"] = not result["aborted"] and result["failed"] == 0
        return result
