"""Two real localhost HTTP APIs with deterministic faults and a durable receiver."""
from __future__ import annotations
import argparse
import hashlib
import json
import socket
import sqlite3
import threading
import time
from collections import Counter
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit
from .core import ID, SHA, MAX_BYTES, digest, utc_now

DEMO_TOKEN = "fictional-local-demo-token"
FIXTURES = Path(__file__).resolve().parent.parent / "fixtures"


class DemoState:
    def __init__(self, workdir: Path, *, faults: bool = True, fixtures: Path = FIXTURES):
        workdir.mkdir(parents=True, exist_ok=True)
        self.database = workdir / "receiver.sqlite"
        self.batches = {p.stem: p.read_bytes() for p in sorted(fixtures.glob("*.csv"))}
        self.faults, self.recovered = faults, False
        self.calls, self.events = Counter(), []
        self.lock = threading.RLock()
        self.source_token = DEMO_TOKEN
        self.tamper_batch = None
        self.manifest_cycle = False
        self.redirect_source = False
        self.force_receiver_status = None
        self.bad_receipt = False
        self.page_size = 3
        with sqlite3.connect(self.database) as db:
            db.execute("""CREATE TABLE IF NOT EXISTS receipts (
                idempotency_key TEXT PRIMARY KEY, receipt_id TEXT UNIQUE NOT NULL,
                batch_id TEXT NOT NULL, sha256 TEXT NOT NULL, body BLOB NOT NULL,
                created_at TEXT NOT NULL)""")

    def record(self, operation, batch_id=None, **fields):
        with self.lock:
            self.events.append({"at": utc_now(), "operation": operation,
                                "batch_id": batch_id, **fields})

    def count(self, operation, batch_id=None):
        with self.lock:
            self.calls[(operation, batch_id)] += 1
            return self.calls[(operation, batch_id)]

    def receipts(self):
        with sqlite3.connect(self.database) as db:
            db.row_factory = sqlite3.Row
            rows = db.execute("SELECT * FROM receipts ORDER BY batch_id").fetchall()
            return [dict(row) for row in rows]

    def ingest(self, key, bid, sha, body):
        # Atomic key uniqueness in SQLite, not a check-then-write in Python.
        with sqlite3.connect(self.database) as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT receipt_id,batch_id,sha256,body FROM receipts WHERE idempotency_key=?",
                             (key,)).fetchone()
            if row:
                if row[1] != bid or row[2] != sha or row[3] != body:
                    return None
                rid, replayed = row[0], True
            else:
                rid, replayed = "rcpt-" + key[:16], False
                db.execute("INSERT INTO receipts VALUES (?,?,?,?,?,?)",
                           (key, rid, bid, sha, body, utc_now()))
            return {"receipt_id": rid, "batch_id": bid, "sha256": sha,
                    "bytes": len(body), "idempotency_key": key, "replayed": replayed}


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"

    def log_message(self, fmt, *args):
        pass  # No default HTTP logs: they may contain data we did not allowlist.

    @property
    def state(self):
        return self.server.state

    def reply(self, status, data, *, headers=None, raw=False):
        payload = data if raw else json.dumps(data).encode()
        self.send_response(status)
        self.send_header("Content-Type", "text/csv" if raw else "application/json")
        self.send_header("Content-Length", str(len(payload)))
        for k, v in (headers or {}).items():
            self.send_header(k, str(v))
        self.end_headers()
        try:
            self.wfile.write(payload)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_GET(self):
        if self.server.role != "source":
            return self.reply(404, {"error": "not_found"})
        parts = urlsplit(self.path)
        operation = "list" if parts.path == "/batches" else "fetch"
        bid = parts.path.removeprefix("/batches/") if operation == "fetch" else None
        attempt = self.state.count(operation, bid)
        if self.headers.get("Authorization") != "Bearer " + self.state.source_token:
            self.state.record(operation, bid, status=401)
            return self.reply(401, {"error": "unauthorized"})
        if self.state.redirect_source:
            self.state.record(operation, bid, status=302)
            return self.reply(302, {}, headers={"Location": "http://example.invalid/blocked"})
        if parts.path == "/batches":
            query = parse_qs(parts.query)
            cursor = query.get("cursor", ["0"])[0]
            if not cursor.isdigit():
                return self.reply(400, {"error": "bad_cursor"})
            start = int(cursor)
            ids = sorted(self.state.batches)
            selected = ids[start:start + self.state.page_size]
            following = start + len(selected)
            next_cursor = str(following) if following < len(ids) else None
            if self.state.manifest_cycle:
                next_cursor = cursor
            items = [{"id": name, "sha256": digest(self.state.batches[name]),
                      "bytes": len(self.state.batches[name])} for name in selected]
            self.state.record("list", status=200, items=len(items), cursor=cursor)
            return self.reply(200, {"items": items, "next_cursor": next_cursor})
        if not parts.path.startswith("/batches/") or bid not in self.state.batches:
            return self.reply(404, {"error": "not_found"})
        if self.state.faults and bid == "parts-003" and attempt == 1:
            self.state.record("fetch", bid, status=429, retry_after="0")
            return self.reply(429, {"error": "demo_rate_limit"}, headers={"Retry-After": "0"})
        body = self.state.batches[bid]
        if bid == self.state.tamper_batch:
            body += b"changed-in-transit"
        self.state.record("fetch", bid, status=200, bytes=len(body))
        return self.reply(200, body, raw=True)

    def do_POST(self):
        if self.server.role != "receiver" or self.path != "/ingest":
            return self.reply(404, {"error": "not_found"})
        bid = self.headers.get("X-Batch-ID", "")
        key = self.headers.get("Idempotency-Key", "")
        sha = self.headers.get("X-Content-SHA256", "")
        try:
            length = int(self.headers.get("Content-Length", "-1"))
        except ValueError:
            length = -1
        if not (ID.fullmatch(bid) and SHA.fullmatch(key) and SHA.fullmatch(sha)
                and 0 <= length <= MAX_BYTES):
            return self.reply(400, {"error": "invalid_request"})
        self.connection.settimeout(3)
        body = self.rfile.read(length)
        attempt = self.state.count("send", bid)
        common = {"idempotency_key": key, "attempt": attempt,
                  "authorization_present": self.headers.get("Authorization") is not None}
        if len(body) != length or digest(body) != sha:
            self.state.record("send", bid, status=400, **common)
            return self.reply(400, {"error": "digest_mismatch"})
        forced = self.state.force_receiver_status
        if forced:
            self.state.record("send", bid, status=forced, **common)
            return self.reply(forced, {"error": "injected"})
        if self.state.faults:
            if (bid == "parts-004" and attempt == 1) or (bid == "parts-006" and not self.state.recovered):
                self.state.record("send", bid, status=503, **common)
                return self.reply(503, {"error": "demo_unavailable"})
            if bid == "parts-007" and not self.state.recovered:
                self.state.record("send", bid, status=400, **common)
                return self.reply(400, {"error": "demo_receiver_validation_rule"})
        receipt = self.state.ingest(key, bid, sha, body)
        if receipt is None:
            self.state.record("send", bid, status=409, **common)
            return self.reply(409, {"error": "idempotency_conflict"})
        if self.state.faults and bid == "parts-005" and attempt == 1:
            # COMMIT has completed, then the response is deliberately lost.
            self.state.record("send", bid, status=None, action="committed_then_dropped_response",
                              receipt_id=receipt["receipt_id"], **common)
            self.connection.shutdown(socket.SHUT_RDWR)
            self.connection.close()
            self.close_connection = True
            return
        status = 200 if receipt["replayed"] else 201
        self.state.record("send", bid, status=status, receipt_id=receipt["receipt_id"],
                          replayed=receipt["replayed"], **common)
        if self.state.bad_receipt:
            receipt["sha256"] = "0" * 64
        return self.reply(status, receipt)


class DemoCluster:
    def __init__(self, workdir: Path, *, faults=True, fixtures=FIXTURES):
        self.state = DemoState(workdir, faults=faults, fixtures=fixtures)
        self.servers, self.threads = [], []

    def __enter__(self):
        for role in ("source", "receiver"):
            server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
            server.daemon_threads = True
            server.role, server.state = role, self.state
            thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.05}, daemon=True)
            thread.start()
            self.servers.append(server)
            self.threads.append(thread)
            setattr(self, role, f"http://127.0.0.1:{server.server_port}")
        return self

    def __exit__(self, *args):
        for server in self.servers:
            server.shutdown()
            server.server_close()
        for thread in self.threads:
            thread.join(timeout=2)


def main():
    parser = argparse.ArgumentParser(description="Two local mock APIs; Ctrl+C stops both")
    parser.add_argument("--workdir", type=Path, default=Path(".mock-api"))
    parser.add_argument("--faults", action="store_true", help="Enable teaching failure scenarios")
    args = parser.parse_args()
    with DemoCluster(args.workdir, faults=args.faults) as cluster:
        config = {"source": cluster.source, "receiver": cluster.receiver,
                  "source_token": DEMO_TOKEN, "fictional_only": True}
        (args.workdir / "endpoints.json").write_text(json.dumps(config, indent=2) + "\n")
        print(json.dumps(config), flush=True)
        print("Local demo only. Ctrl+C stops both APIs.", flush=True)
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
