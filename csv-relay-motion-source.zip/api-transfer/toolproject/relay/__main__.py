"""Run with python -m relay --help. No installation needed."""
import argparse
import json
import os
import sys
import sqlite3
from pathlib import Path
from .core import Audit, Relay, RelayError, RetryPolicy
from .outputs import fresh_name, validate_outputs


def main(argv=None):
    parser = argparse.ArgumentParser(description="Loopback-only byte-preserving CSV relay demo")
    parser.add_argument("--source", required=True, help="http://127.0.0.1:PORT")
    parser.add_argument("--receiver", required=True, help="http://127.0.0.1:PORT")
    parser.add_argument("--route", default="fictional-parts-v1", help="Stable logical source/receiver pair")
    parser.add_argument("--ledger", type=Path, default=Path(".run/ledger.sqlite"))
    parser.add_argument("--log", type=Path, default=Path(".run/events.jsonl"))
    parser.add_argument("--report", type=Path, default=Path(".run") / (fresh_name("report") + ".json"))
    parser.add_argument("--overwrite-report", action="store_true", help="Explicitly replace an existing report file")
    parser.add_argument("--max-attempts", type=int, default=3)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--dry-run", action="store_true", help="GET and verify only; no POST or ledger writes")
    modes.add_argument("--retry-failed", action="store_true", help="Only failed/pending ledger entries")
    args = parser.parse_args(argv)
    try:
        validate_outputs(args.ledger, args.log, args.report, overwrite_report=args.overwrite_report)
        audit = Audit(args.log)
        runner = Relay(args.source, args.receiver, os.environ.get("RELAY_SOURCE_TOKEN", ""),
                       ledger_path=args.ledger, route=args.route, audit=audit,
                       policy=RetryPolicy(max_attempts=args.max_attempts))
        result = runner.run(dry_run=args.dry_run, retry_failed=args.retry_failed)
        args.report.parent.mkdir(parents=True, exist_ok=True)
        with args.report.open("w" if args.overwrite_report else "x", encoding="utf-8") as output:
            output.write(json.dumps(result, indent=2) + "\n")
        print(json.dumps({k: result[k] for k in ("mode", "discovered", "succeeded", "failed",
                                                "skipped", "would_send", "aborted", "ok")}))
        return 0 if result["ok"] else 1
    except (RelayError, ValueError) as exc:
        code = exc.code if isinstance(exc, RelayError) else "invalid_configuration"
        print(json.dumps({"ok": False, "error": code}), file=sys.stderr)
        return 2
    except (OSError, sqlite3.Error):
        print(json.dumps({"ok": False, "error": "local_storage_error"}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
