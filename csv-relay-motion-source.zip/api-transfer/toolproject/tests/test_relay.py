"""Real HTTP integration tests. No mocked HTTP client and no external network."""
import concurrent.futures
import json
import os
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from email.utils import format_datetime
from pathlib import Path

from relay.core import (Audit, HttpClient, Relay, RelayError, RetryPolicy,
                        digest, local_base, retry_delay, stable_key)
from relay.mock_api import DEMO_TOKEN, DemoCluster
from relay.outputs import output_directory, validate_outputs


class LiveHTTPTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.cluster = DemoCluster(self.root / "server", faults=False).__enter__()
        self.audit = Audit(self.root / "events.jsonl")
        self.ledger = self.root / "ledger.sqlite"
        self.runner = Relay(self.cluster.source, self.cluster.receiver, DEMO_TOKEN,
                            ledger_path=self.ledger, audit=self.audit,
                            policy=RetryPolicy(base_delay=0.001))

    def tearDown(self):
        self.cluster.__exit__(None, None, None)
        self.tmp.cleanup()

    def one_batch(self, bid="parts-001"):
        self.cluster.state.batches = {bid: self.cluster.state.batches[bid]}

    def test_paginated_byte_exact_transfer_and_idempotent_rerun(self):
        result = self.runner.run()
        self.assertTrue(result["ok"])
        self.assertEqual(result["succeeded"], 8)
        self.assertEqual(self.cluster.state.calls[("list", None)], 3)
        for row in self.cluster.state.receipts():
            self.assertEqual(row["body"], self.cluster.state.batches[row["batch_id"]])
        attempts_before = sum(v for (op, _), v in self.cluster.state.calls.items() if op == "send")
        again = self.runner.run()
        self.assertEqual(again["skipped"], 8)
        self.assertEqual(again["succeeded"], 0)
        self.assertEqual(len(self.cluster.state.receipts()), 8)
        self.assertEqual(attempts_before, sum(v for (op, _), v in self.cluster.state.calls.items() if op == "send"))

    def test_scripted_failure_recovery_and_stable_ambiguous_commit_key(self):
        self.cluster.state.faults = True
        first = self.runner.run()
        self.assertEqual((first["succeeded"], first["failed"]), (6, 2))
        state = self.cluster.state
        self.assertEqual(state.calls[("fetch", "parts-003")], 2)  # 429 then 200
        self.assertEqual(state.calls[("send", "parts-004")], 2)   # 503 then 201
        self.assertEqual(state.calls[("send", "parts-006")], 3)   # budget exhausted
        self.assertEqual(state.calls[("send", "parts-007")], 1)   # 400 not retried
        lost = [e for e in state.events if e["operation"] == "send" and e["batch_id"] == "parts-005"]
        self.assertEqual(lost[0]["action"], "committed_then_dropped_response")
        self.assertEqual(lost[0]["idempotency_key"], lost[1]["idempotency_key"])
        self.assertEqual(lost[0]["receipt_id"], lost[1]["receipt_id"])
        self.assertTrue(lost[1]["replayed"])
        self.assertEqual(len([r for r in state.receipts() if r["batch_id"] == "parts-005"]), 1)
        state.recovered = True
        second = self.runner.run(retry_failed=True)
        self.assertEqual((second["succeeded"], second["failed"], second["skipped"]), (2, 0, 6))
        self.assertEqual(len(state.receipts()), 8)

    def test_dry_run_has_no_post_and_creates_no_ledger(self):
        result = self.runner.run(dry_run=True)
        self.assertEqual(result["would_send"], 8)
        self.assertFalse(self.ledger.exists())
        self.assertEqual(len(self.cluster.state.receipts()), 0)
        self.assertFalse(any(op == "send" for op, _ in self.cluster.state.calls))

    def test_source_401_aborts_without_retry_or_write(self):
        self.runner.token = "wrong-fictional-value"
        result = self.runner.run()
        self.assertTrue(result["aborted"])
        self.assertEqual(result["error"], "http_401")
        self.assertEqual(self.cluster.state.calls[("list", None)], 1)
        self.assertFalse(self.ledger.exists())
        self.assertEqual(len(self.cluster.state.receipts()), 0)

    def test_receiver_401_aborts_remaining_batches_without_retry(self):
        self.cluster.state.force_receiver_status = 401
        result = self.runner.run()
        self.assertTrue(result["aborted"])
        self.assertEqual(len(result["batches"]), 1)
        self.assertEqual(self.cluster.state.calls[("send", "parts-001")], 1)

    def test_receiver_400_is_not_retried(self):
        self.one_batch()
        self.cluster.state.force_receiver_status = 400
        result = self.runner.run()
        self.assertEqual(result["failed"], 1)
        self.assertEqual(self.cluster.state.calls[("send", "parts-001")], 1)

    def test_integrity_mismatch_never_reaches_receiver(self):
        self.one_batch()
        self.cluster.state.tamper_batch = "parts-001"
        result = self.runner.run()
        self.assertEqual(result["batches"][0]["error"], "source_integrity_mismatch")
        self.assertEqual(len(self.cluster.state.receipts()), 0)
        self.assertEqual(self.cluster.state.calls[("send", "parts-001")], 0)

    def test_bad_receipt_is_failure_then_reconciles_with_same_key(self):
        self.one_batch()
        self.cluster.state.bad_receipt = True
        result = self.runner.run()
        self.assertEqual(result["batches"][0]["error"], "receiver_receipt_mismatch")
        self.assertEqual(len(self.cluster.state.receipts()), 1)
        self.cluster.state.bad_receipt = False
        retried = self.runner.run(retry_failed=True)
        self.assertTrue(retried["ok"])
        self.assertTrue(retried["batches"][0]["replayed"])
        self.assertEqual(len(self.cluster.state.receipts()), 1)

    def test_new_local_ledger_does_not_duplicate_receiver_receipts(self):
        self.one_batch()
        self.assertTrue(self.runner.run()["ok"])
        self.runner.ledger_path = self.root / "new-ledger.sqlite"
        result = self.runner.run()
        self.assertTrue(result["batches"][0]["replayed"])
        self.assertEqual(len(self.cluster.state.receipts()), 1)

    def test_changed_batch_identity_is_blocked(self):
        self.one_batch()
        self.assertTrue(self.runner.run()["ok"])
        self.cluster.state.batches["parts-001"] += b"new row\n"
        result = self.runner.run()
        self.assertEqual(result["batches"][0]["error"], "batch_identity_changed")
        self.assertEqual(self.cluster.state.calls[("send", "parts-001")], 1)

    def test_failed_only_mode_skips_unseen_batches(self):
        result = self.runner.run(retry_failed=True)
        self.assertEqual(result["skipped"], 8)
        self.assertEqual(result["succeeded"], 0)
        self.assertEqual(len(self.cluster.state.receipts()), 0)

    def test_pagination_cycle_aborts(self):
        self.cluster.state.manifest_cycle = True
        result = self.runner.run()
        self.assertEqual(result["error"], "pagination_cycle")
        self.assertEqual(self.cluster.state.calls[("list", None)], 1)

    def test_redirect_is_not_followed(self):
        self.cluster.state.redirect_source = True
        result = self.runner.run()
        self.assertEqual(result["error"], "http_302")
        self.assertEqual(self.cluster.state.calls[("list", None)], 1)

    def test_token_never_forwarded_or_logged(self):
        self.assertTrue(self.runner.run()["ok"])
        sends = [e for e in self.cluster.state.events if e["operation"] == "send"]
        self.assertTrue(sends)
        self.assertTrue(all(not e["authorization_present"] for e in sends))
        log = (self.root / "events.jsonl").read_text()
        self.assertNotIn(DEMO_TOKEN, log)
        self.assertNotIn("Bearer", log)
        self.assertNotIn("Seal kit", log)

    def test_receiver_rejects_reused_key_with_different_bytes(self):
        self.one_batch()
        self.assertTrue(self.runner.run()["ok"])
        row = self.cluster.state.receipts()[0]
        body = b"different,content\n"
        with self.assertRaises(RelayError) as ctx:
            self.runner.http.request("POST", self.cluster.receiver, "/ingest", operation="send",
                body=body, headers={"X-Batch-ID": row["batch_id"], "Idempotency-Key": row["idempotency_key"],
                                    "X-Content-SHA256": digest(body)})
        self.assertEqual(ctx.exception.status, 409)
        self.assertEqual(len(self.cluster.state.receipts()), 1)

    def test_concurrent_receiver_duplicate_requests_commit_once(self):
        self.one_batch()
        body = self.cluster.state.batches["parts-001"]
        key = stable_key("test-route", "parts-001", digest(body))
        def submit(_):
            client = HttpClient(Audit(), RetryPolicy(base_delay=0))
            _, _, data = client.request("POST", self.cluster.receiver, "/ingest", operation="send",
                body=body, headers={"X-Batch-ID": "parts-001", "Idempotency-Key": key,
                                    "X-Content-SHA256": digest(body)})
            return json.loads(data)
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            receipts = list(pool.map(submit, range(4)))
        self.assertEqual(len(self.cluster.state.receipts()), 1)
        self.assertEqual(len({r["receipt_id"] for r in receipts}), 1)
        self.assertEqual(sum(not r["replayed"] for r in receipts), 1)

    def test_cli_rejects_output_collision_before_network(self):
        env = os.environ.copy()
        env["RELAY_SOURCE_TOKEN"] = DEMO_TOKEN
        completed = subprocess.run([sys.executable, "-m", "relay", "--source", self.cluster.source,
            "--receiver", self.cluster.receiver, "--ledger", str(self.ledger),
            "--report", str(self.ledger), "--log", str(self.root / "cli.jsonl")],
            env=env, text=True, capture_output=True, timeout=15)
        self.assertEqual(completed.returncode, 2)
        self.assertEqual(json.loads(completed.stderr)["error"], "output_paths_collide")
        self.assertFalse(self.ledger.exists())
        self.assertFalse((self.root / "cli.jsonl").exists())
        self.assertEqual(len(self.cluster.state.events), 0)

    def test_output_hardlink_collisions_are_rejected(self):
        original, alias = self.root / "existing", self.root / "alias"
        original.write_bytes(b"preserve me")
        os.link(original, alias)
        with self.assertRaisesRegex(RelayError, "output_paths_collide"):
            validate_outputs(original, self.root / "log", alias, overwrite_report=True)
        self.assertEqual(original.read_bytes(), b"preserve me")

    def test_sqlite_sidecar_output_collisions_are_rejected(self):
        for suffix in ("-journal", "-wal", "-shm"):
            with self.subTest(suffix=suffix), self.assertRaisesRegex(RelayError, "sqlite_sidecar"):
                validate_outputs(self.ledger, self.root / "events.jsonl", Path(str(self.ledger) + suffix))

    def test_existing_report_and_unrelated_log_are_preserved(self):
        report, log = self.root / "report", self.root / "log"
        report.write_text("preserve report")
        with self.assertRaisesRegex(RelayError, "report_exists"):
            validate_outputs(self.ledger, log, report)
        validate_outputs(self.ledger, log, report, overwrite_report=True)
        log.write_text("preserve unrelated file")
        with self.assertRaisesRegex(RelayError, "existing_log_is_not_event_jsonl"):
            validate_outputs(self.ledger, log, report, overwrite_report=True)
        self.assertEqual(log.read_text(), "preserve unrelated file")
        self.assertEqual(report.read_text(), "preserve report")

    def test_existing_output_directory_requires_explicit_overwrite(self):
        output = self.root / "evidence"
        output.mkdir()
        (output / "old-report.json").write_text("preserve evidence")
        with self.assertRaisesRegex(RelayError, "output_directory_not_empty"):
            output_directory(output, self.root, "demo", False)
        self.assertEqual(output_directory(output, self.root, "demo", True), output.resolve())
        self.assertEqual((output / "old-report.json").read_text(), "preserve evidence")

    def test_cli_runs_as_a_real_subprocess(self):
        env = os.environ.copy()
        env["RELAY_SOURCE_TOKEN"] = DEMO_TOKEN
        completed = subprocess.run([sys.executable, "-m", "relay", "--source", self.cluster.source,
            "--receiver", self.cluster.receiver, "--ledger", str(self.ledger),
            "--report", str(self.root / "report.json"), "--log", str(self.root / "cli.jsonl")],
            env=env, text=True, capture_output=True, timeout=15)
        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertEqual(json.loads(completed.stdout)["succeeded"], 8)


class PolicyTests(unittest.TestCase):
    def test_nonlocal_urls_and_userinfo_are_rejected(self):
        for url in ("https://api.example.com", "http://localhost:9000", "http://127.0.0.1.evil:80",
                    "http://127.0.0.1:80/foo", "http://user:pass@127.0.0.1:80", "http://127.0.0.1:80?x=y"):
            with self.subTest(url=url), self.assertRaises(RelayError):
                local_base(url)
        self.assertEqual(local_base("http://127.0.0.1:1234/"), "http://127.0.0.1:1234")

    def test_retry_after_numeric_date_invalid_and_over_budget(self):
        policy = RetryPolicy(base_delay=0.1, max_delay=2)
        self.assertEqual(retry_delay("1", 1, policy), 1)
        future = format_datetime(datetime.now(timezone.utc) + timedelta(seconds=2), usegmt=True)
        self.assertGreater(retry_delay(future, 1, policy), 0.8)
        self.assertEqual(retry_delay("not-a-date", 2, policy), 0.2)
        with self.assertRaisesRegex(RelayError, "retry_after_exceeds_budget"):
            retry_delay("999999", 1, policy)

    def test_invalid_retry_policy_rejected(self):
        for args in ({"max_attempts": 0}, {"timeout": 0}, {"max_delay": float("inf")}, {"base_delay": -1}):
            with self.subTest(args=args), self.assertRaises(ValueError):
                RetryPolicy(**args)

    def test_idempotency_key_is_stable_and_route_scoped(self):
        sha = digest(b"raw CSV\r\n")
        self.assertEqual(stable_key("a", "batch-1", sha), stable_key("a", "batch-1", sha))
        self.assertNotEqual(stable_key("a", "batch-1", sha), stable_key("b", "batch-1", sha))
        self.assertNotEqual(stable_key("a", "batch-1", sha), stable_key("a", "batch-1", digest(b"changed")))


if __name__ == "__main__":
    unittest.main(verbosity=2)
