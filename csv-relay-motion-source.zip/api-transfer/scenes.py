POLISH_TILE = 52

POLISH_GAP = 16

POLISH_COLS = 4

POLISH_GRID_W = POLISH_COLS * POLISH_TILE + (POLISH_COLS - 1) * POLISH_GAP

POLISH_GRID_TOP = 560

def polish_slot(card_x, card_w, i):
    gx = card_x + (card_w - POLISH_GRID_W) / 2
    step = POLISH_TILE + POLISH_GAP
    return gx + (i % POLISH_COLS) * step, POLISH_GRID_TOP + (i // POLISH_COLS) * step

def polish_tile(c, x, y, n, fill, stroke, color='plum'):
    rect(c, x, y, POLISH_TILE, POLISH_TILE, fill, stroke)
    text(c, str(n), x + POLISH_TILE / 2, y + 35, 26, color, align='center')

def polish_token(c, label, x, y, w=110, h=44, fill='paper', stroke='lavender'):
    rect(c, x, y, w, h, fill, stroke)
    text(c, label, x + w / 2, y + 31, 26, 'plum', align='center')

def polish_lift(p):
    return 4 * p * (1 - p)

PROJECT='CSV Relay Lab'
DURATIONS=[12, 14, 12, 12, 16, 24, 10, 14, 16, 12, 14]
TITLES=['Which CSVs arrived?', '8 CSV batches. The same bytes arrive.', 'One local demonstration command.', 'Check first. Send nothing.', 'Two deliberate faults remain.', 'Saved at the receiver. Reply lost.', 'Fix the cause, then retry failures.', 'Recover two. Leave six completed.', 'New work uses a normal run.', 'Why the retry is safe here.', 'Try the local example.']
SUBTITLES=['For operations teams and developers · Final outcome preview', 'Sent and received details stay unchanged', 'One helper command runs the local demo', 'Phase 1 dry run: nothing is sent', 'Phase 2 injected failure: 6 delivered, 2 failed', 'Inside the initial run: parts-005 is one of the six successes', 'Scripted helper removes the two deliberately injected faults', 'Automatic recovery phase, then a normal rerun', 'Separate ninth-batch exercise · Compare two run modes', 'Receiver contract required · A sender ledger alone is insufficient', 'Start with the companion source ZIP and WORKFLOW.md']
MODES=['ILLUSTRATED EXPLANATION', 'ILLUSTRATED EXPLANATION', 'EXAMPLE COMMAND', 'ILLUSTRATED EXPLANATION', 'ILLUSTRATED EXPLANATION', 'ILLUSTRATED EXPLANATION', 'ILLUSTRATED EXPLANATION', 'ILLUSTRATED EXPLANATION', 'ILLUSTRATED EXPLANATION', 'SAVED-RUN EXCERPT + DIAGRAM', 'ILLUSTRATED EXPLANATION']
from art import *

TOK = ['batch-1', 'batch-2', 'batch-3', 'batch-4', 'batch-5', 'batch-6', 'batch-7', 'batch-8']


def stage(t, s=1.2, d=2.4):
    return ease(progress(t, s, d))


def tag(c, s='Illustration'):
    text(c, s, 1500, 735, 26, 'gray', align='right')


def token(c, label, x, y, w=150, h=44, color='lavender'):
    rect(c, x, y, w, h, 'paper', color)
    text(c, label, x + w / 2, y + 31, 26, 'plum', align='center')


def pill(c,label,x,y,w=210,color='plum'):
    rect(c,x,y,w,48,color);text(c,label,x+15,y+34,27,'plum' if color=='lavender' else 'paper',bold=True)

def draw_0(c, t):
    text(c, 'Preview of the final outcome: all 8 CSV files arrive.', 80, 296, 34, 'plum', True)
    text(c, 'Next, the story rewinds to show how it got there.', 80, 342, 30, 'plum')
    text(c, 'Local mock services only: not a live SaaS or production system.', 80, 390, 28, 'coral')

    sx, rx, cw = 80, 1140, 380
    paper(c, sx, 420, cw, 300, 'lavender')
    text(c, 'Source API', sx + cw / 2, 468, 32, 'plum', True, align='center')
    text(c, 'local mock service', sx + cw / 2, 504, 26, 'gray', align='center')
    paper(c, rx, 420, cw, 300, 'coral')
    text(c, 'Receiver API', rx + cw / 2, 468, 32, 'plum', True, align='center')
    text(c, 'local mock service', rx + cw / 2, 504, 26, 'gray', align='center')

    for i in range(8):
        x, y = polish_slot(sx, cw, i)
        polish_tile(c, x, y, i + 1, 'oyster', 'edge', 'gray')
        x, y = polish_slot(rx, cw, i)
        rect(c, x, y, POLISH_TILE, POLISH_TILE, 'oyster', 'edge')

    arrow(c, 480, 700, 1120, 700, 'lavender')

    n = 0
    for i in range(8):
        p = ease(progress(t, 1.2 + i * 0.4, 1.4))
        if p >= 1:
            n += 1
        if p <= 0:
            continue
        ax, ay = polish_slot(sx, cw, i)
        bx, by = polish_slot(rx, cw, i)
        polish_tile(c, mix(ax, bx, p), ay - 12 * polish_lift(p), i + 1,
                    'coral' if p >= 1 else 'lavender', 'plum')

    text(c, 'arrived: %d / 8' % n, 800, 470, 34, 'plum', True, align='center')
    text(c, 'final result, shown first', 800, 512, 26, 'gray', align='center')



def draw_1(c, t):
    text(c, '8 fictional CSV files × 3 parts rows = 24 rows', 80, 296, 34, 'plum', True)
    text(c, 'Selected properties from the real fixtures, not whole file contents', 80, 340, 28, 'gray')
    items = [
        ('parts-004.csv', 'Comma inside quotes', 'quoted comma', '"Valve, brass"'),
        ('parts-007.csv', 'Non-ASCII dash', 'Unicode en dash', 'Gasket – medium'),
        ('parts-001.csv', 'Windows line endings', 'technical: CRLF', 'line ends: CRLF'),
        ('parts-008.csv', 'UTF-8 encoding marker', 'technical: BOM', 'starts with BOM'),
    ]
    y0 = 366
    for j, (fname, plain, tech, val) in enumerate(items):
        x = 80 + j * 365
        paper(c, x, y0, 345, 330)
        text(c, fname, x + 20, y0 + 44, 26, 'gray', mono=True)
        text(c, plain, x + 20, y0 + 84, 26, 'plum', True)
        text(c, tech, x + 20, y0 + 118, 26, 'gray')
        text(c, 'SENT', x + 20, y0 + 168, 26, 'gray', True)
        text(c, val, x + 20, y0 + 204, 26, 'plum', mono=True)
        q = ease(progress(t, 1.2 + j * .65, 1.6))
        arrow(c, x + 172, y0 + 216, x + 172, y0 + 216 + 34 * q, 'lavender', 3)
        text(c, 'RECEIVED', x + 20, y0 + 278, 26, 'gray', True)
        alpha(c, q, lambda x=x, val=val: (
            text(c, val, x + 20, y0 + 314, 26, 'plum', mono=True),
            tick(c, x + 295, y0 + 270)))
    text(c, 'SENT = RECEIVED: bytes unchanged. No parsing, cleaning or business-value checks.',
         80, 735, 28, 'plum', True)



def draw_2(c, t):
    text(c, 'Run one terminal command from the project folder.', 80, 295, 32, 'plum', True)
    paper(c, 80, 316, 1440, 76, 'plum')
    text(c, 'python3 scripts/run_demo.py --output runs/my-demo-run', 110, 365, 32, 'plum', mono=True)
    text(c, 'The helper automatically starts two local test servers and exercises failures and recovery,',
         80, 440, 28, 'plum')
    text(c, 'saves the results, then stops both servers.', 80, 474, 28, 'plum')

    for x, lab in ((220, 'source 127.0.0.1'), (1000, 'receiver 127.0.0.1')):
        paper(c, x, 500, 380, 110, 'lavender')
        text(c, lab, x + 190, 545, 28, 'plum', True, align='center')
        text(c, 'temporary local server', x + 190, 590, 26, 'gray', align='center')
    arrow(c, 600, 555, 1000, 555, 'lavender')

    steps = [('start', 1.2, 615), ('run', 3.4, 745), ('stop', 6.0, 875)]
    for lab, s, x in steps:
        on = ease(progress(t, s, 1.0))
        polish_token(c, lab, x, 533, 110, 44, 'rose' if on > .5 else 'paper',
                     'coral' if on > .5 else 'lavender')

    text(c, 'Results go to a fresh output folder: runs/my-demo-run', 80, 655, 28, 'plum')
    text(c, 'Run from api-transfer/toolproject/ with Python 3.10+; no further package install.',
         80, 695, 28, 'plum')
    text(c, 'Setup steps are in the root WORKFLOW.md.', 80, 735, 28, 'gray')



def draw_3(c, t):
    text(c, 'Phase 1: dry run. A rehearsal that sends nothing.', 80, 296, 34, 'plum', True)
    paper(c, 80, 350, 700, 340, 'coral')
    text(c, 'Dry-run checklist (illustration)', 110, 400, 30, 'plum', True)
    count = 0
    for i in range(8):
        q = progress(t, 1.2 + i * .35, .8)
        done = q >= 1
        count += int(done)
        x = 110 + (i % 4) * 165
        y = 440 + (i // 4) * 65
        polish_token(c, 'file %d' % (i + 1), x, y, 150, 44,
                     'rose' if done else 'paper', 'coral' if done or q > 0 else 'edge')
    text(c, f'{count} would send', 110, 620, 32, 'plum', True)
    text(c, 'No files leave the sender.', 110, 662, 26, 'gray')
    line(c, 810, 365, 810, 695, 'coral', 4, [8, 6])
    paper(c, 840, 350, 680, 340, 'lavender')
    rows = [('0 POSTs', 'POST = a send request'),
            ('0 receipts', "receipt = receiver's acknowledgment"),
            ('No ledger created', "ledger = sender's progress record")]
    for i, (a, b) in enumerate(rows):
        y = 420 + i * 95
        text(c, a, 880, y, 34, 'plum', True)
        text(c, b, 880, y + 36, 26, 'gray')
        tick(c, 1470, y - 8, 'coral')
    text(c, 'Next, Phase 2 adds an injected failure.', 80, 735, 26, 'gray')




def phase(t, s, d):
    return ease(progress(t, s, d))

def box(c, x, y, w, h, label, fill='oyster', stroke='edge', color='plum', size=26):
    rect(c, x, y, w, h, fill=fill, stroke=stroke)
    text(c, label, x + w / 2, y + h / 2 + 9, size, color, align='center')

# ---------- Scene 5 (50-66s): two deliberate faults ----------
def draw_4(c, t):
    text(c, "6 delivered, 2 failed after bounded automatic retries", 80, 295, 32, 'plum', True)
    paper(c, 80, 400, 800, 200)
    paper(c, 920, 400, 600, 200)
    text(c, "Delivered (6) - completed records stay", 100, 435, 26, 'gray')
    text(c, "Failed (2) - still visible", 940, 435, 26, 'coral')
    ids = [1, 2, 3, 4, 5, 8, 6, 7]
    for i,n in enumerate(ids):
        sx=80+(n-1)*180
        e=phase(t,1.2+i*.35,1.0);failed=i>=6
        token(c,'parts-00%d'%n,sx,320,160,44,'coral' if failed and e>=1 else 'edge')
        if 0<e<1:outline(c,sx,320,160,44,'coral' if failed else 'lavender')
        tx=940 if failed else 100+(i%3)*250
        ty=460+(i-6)*60 if failed else 460+(i//3)*60
        alpha(c,e,lambda n=n,tx=tx,ty=ty,failed=failed:pill(c,'parts-00%d'%n,tx,ty,200 if failed else 220,'coral' if failed else 'lavender'))
    e = phase(t, 3.8, 1)
    if e > 0:
        text(c, "503: retried, still failed", 1170, 490, 26, 'coral')
        text(c, "400: rejected, stopped", 1170, 550, 26, 'coral')
        text(c, "503 is temporary: bounded retries may run again.", 80, 650, 28, 'plum')
        text(c, "400 is a bad request: that attempt stops, no retry.", 80, 700, 28, 'plum')

# ---------- Scene 6 (66-90s): saved at receiver, reply lost ----------
def draw_5(c, t):
    paper(c, 80, 270, 360, 300)
    paper(c, 1040, 270, 480, 300)
    text(c, "Sender", 100, 310, 32, 'plum', True)
    text(c, "Receiver (mock local HTTP)", 1060, 310, 28, 'plum', True)
    nreq = (1 if t >= 1.5 else 0) + (1 if t >= 13 else 0)
    nst = 1 if t >= 7 else 0
    text(c, "requests sent: %d" % nreq, 100, 540, 28, 'plum')
    text(c, "stored receipts: %d" % nst, 1060, 540, 28, 'plum')
    arrow(c, 450, 355, 1030, 355, 'edge', 2)
    arrow(c, 1030, 470, 450, 470, 'edge', 2)
    text(c, "same transfer key", 740, 310, 26, 'gray', align='center')
    text(c, "key identifies this transfer", 740, 620, 26, 'gray', align='center')
    # request 1
    e = phase(t, 1.5, 2)
    if 1.5 <= t < 4:
        pill(c, "POST parts-005", mix(460, 800, e), 320 if False else 365, 230)
    # Prepare one group; the visible store and count commit together.
    if 4 <= t < 7:
        e=phase(t,4,3);y=mix(345,395,e)
        outline(c,1050,y-10,450,68,'lavender',2)
        for i,(lab,col) in enumerate([('bytes','lavender'),('key','lavender'),('receipt','coral')]):
            pill(c,lab,1060+i*150,y,130,col)
    if 4 <= t < 7:
        text(c, "prepare one record", 1060, 500, 26, 'gray')
    if t >= 7:
        rect(c, 1060, 380, 440, 100, fill='paper', stroke='coral')
        text(c, "bytes + key + receipt", 1080, 415, 26, 'plum')
        text(c, "rcpt-36afa020e3c2a7f6", 1080, 460, 26, 'coral', True, True)
        text(c, "stored together, once", 1060, 612, 26, 'gray')
    # reply lost
    if 10 <= t < 12:
        e = phase(t, 10, 1.2)
        if t < 11.3:
            pill(c, "reply: receipt", mix(1030 - 200, 650, e), 482, 200, 'coral')
        else:
            pill(c, "reply: receipt", 650, 482, 200, 'gray')
            text(c, "lost", 750, 560, 32, 'coral', True, align='center')
    if t >= 12 and t < 13:
        text(c, "reply lost - receipt still stored", 640, 560, 26, 'coral', align='center')
    # request 2
    if 13 <= t < 15.2:
        e = phase(t, 13, 2)
        pill(c, "retry same key", mix(460, 790, e), 365, 240, 'lavender')
    # replay reply
    if 16 <= t:
        e = phase(t, 16, 2)
        pill(c, "same receipt", mix(790, 460, e), 482, 240, 'coral')
    if t >= 18:
        text(c, "2 requests -> 1 stored receipt (original kept)", 800, 680, 30, 'plum', True, align='center')
    text(c, "The receiver must keep the key, bytes and receipt together. Ledger alone is insufficient.", 80, 730, 26, 'plum')


# ---------- Scene 7 (90-100s): fix cause ----------
def draw_6(c, t):
    text(c, 'In this demo, the helper removes both injected faults automatically.', 80, 298, 32, 'plum', True)
    for j,(name,desc) in enumerate([('parts-006','503: retries exhausted'),('parts-007','400: request rejected')]):
        x=80+j*740
        paper(c,x,340,700,240)
        text(c,name,x+28,390,32,'plum',True,True)
        text(c,desc,x+28,440,28,'gray')
        cleared=t>=3+j*.7
        pill(c,'test fault cleared' if cleared else 'injected test fault',x+28,485,330,'lavender' if cleared else 'coral')
        if cleared:tick(c,x+410,507,'plum')
    text(c,'For a real failure, a person investigates and fixes the cause before retrying.',80,642,30,'plum')
    text(c,'This scripted exercise does not diagnose or repair production services.',80,697,28,'gray')

# ---------- Scene 8 (100-114s): recover two ----------
def draw_7(c, t):
    text(c, "Sender ledger", 80, 285, 26, 'gray')
    text(c, "Receiver stored receipts", 80, 395, 26, 'gray')
    for i in range(8):
        x = 80 + i * 180
        bad = i in (5, 6)
        e = phase(t, 1.2, 2)
        done = (not bad) or e >= 1
        box(c, x, 300, 160, 50, "parts-00%d" % (i + 1),
            fill='lavender' if done else 'coral')
        have = (not bad) or e >= 1
        box(c, x, 425, 160, 50, "receipt" if have else "none",
            fill='paper' if have else 'oyster', stroke='edge' if have else 'coral')
        if bad and 0 < e < 1:
            pill(c, "POST", x + 10, mix(350, 425, e) - 10, 140, 'coral')
    text(c, "Failed-only run: 2 delivered, 6 skipped, 8 total receipts", 80, 530, 28, 'plum', True)
    e = phase(t, 5, 1)
    if e > 0:
        text(c, "Next normal rerun: 8 skipped, 0 new POSTs", 80, 580, 28, 'plum', True)
    text(c, "Ledger = sender progress; receipt = saved acknowledgment.", 80, 630, 26, 'gray')
    text(c, "All 8 files byte-equal. Results folder: runs/my-demo-run/", 80, 680, 26, 'plum')
    text(c, "Open demo-summary.json for counts; integrity-results.json for byte checks.", 80, 725, 26, 'plum')




def tok(c, s, x, y, w=100, fill='paper', stroke='edge', col='plum'):
    rect(c, x, y, w, 44, fill, stroke)
    text(c, s, x + w / 2, y + 31, 26, col, mono=True, align='center')


def draw_8(c, t):
    text(c, "New batch 009 has no failure to retry: use a normal run.", 80, 298, 32, 'plum', True)
    sx = lambda i: 340 + i * 110
    text(c, "9 files", 80, 352, 28, 'gray')
    for i in range(9):
        tok(c, "%03d" % (i + 1), sx(i), 320, 96, 'paper', 'coral' if i == 8 else 'edge')
    rows = [(430, "failed-only", 'gray'), (540, "normal run", 'plum')]
    for r, (ry, name, col) in enumerate(rows):
        text(c, name, 80, ry + 31, 28, col, True)
        for i in range(9):
            p = ease(progress(t, 1.2 + i * 0.2 + r * 0.1, 1.4))
            y = mix(320, ry, p)
            new = (r == 1 and i == 8)
            fill = 'paper'
            if p >= 1:
                fill = 'lavender' if new else 'oyster'
            tok(c, "%03d" % (i + 1), sx(i), y, 96, fill, 'coral' if new else 'edge')
            a = ease(progress(t, 4.5, 0.8))
            if p >= 1:
                if r == 0:
                    alpha(c, a, lambda  i=i, ry=ry: (
                        
                        text(c, "skip", sx(i) + 48, ry + 80, 26, 'gray', align='center')))
                elif new:
                    alpha(c, a, lambda  i=i, ry=ry: text(
                        c, "POST", sx(i) + 48, ry + 80, 26, 'coral', True, align='center'))
                else:
                    alpha(c, a, lambda  i=i, ry=ry: text(
                        c, "skip", sx(i) + 48, ry + 80, 26, 'gray', align='center'))
        a = ease(progress(t, 4.8, 0.8))
        alpha(c, a, lambda  ry=ry, r=r: text(
            c, "%d POST" % r, 1335, ry + 31, 30, 'coral' if r else 'gray', True))
    a = ease(progress(t, 6.0, 1.0))
    alpha(c, a, lambda: (
        text(c, "9 receipts total; prior 8 unchanged. New work needs a new ID.", 80, 685, 30, 'plum'),
        text(c, "Final rerun: 0 new POSTs", 80, 730, 32, 'coral', True)))


def draw_9(c,t):
    text(c,'This mock receiver keeps three parts together as one record:',80,294,32,'plum',True)
    for i,label in enumerate(['transfer key','original CSV bytes','original receipt']):
        x=80+i*490;q=progress(t,.7+i*.5,.8)
        alpha(c,q,lambda x=x,label=label:(paper(c,x,320,460,95),text(c,label,x+24,380,30,'plum',True)))
    if t>=2.5:outline(c,73,314,1448,108,'coral',3)
    text(c,'Actual saved-run excerpt, typeset from verified results',80,465,27,'gray')
    image(c,'saved-proof.png',80,481,1300,270)


def draw_10(c, t):
    paper(c,80,274,1440,95,spine='coral')
    text(c,'COMPANION SOURCE ZIP',110,309,26,'gray',mono=True)
    text(c,'csv-relay-motion-source.zip',110,351,34,'plum',True,True)
    steps=[('1','Extract the ZIP.','The runnable example is in api-transfer/toolproject/.'),
           ('2','Start with WORKFLOW.md.','At the package root: Python 3.10+ setup and verified steps.'),
           ('3','Run into a new output folder.','Use the fresh-folder commands in that document.')]
    for j,(num,title,detail) in enumerate(steps):
        y=395+j*113;q=progress(t,.4+j*.7,.7)
        def draw_step(y=y,num=num,title=title,detail=detail):
            paper(c,80,y,1440,96,spine='plum');text(c,num,110,y+59,42,'coral',True)
            text(c,title,180,y+39,34,'plum',True);text(c,detail,180,y+78,28,'gray')
        alpha(c,q,draw_step)



SCENES=[draw_0,draw_1,draw_2,draw_3,draw_4,draw_5,draw_6,draw_7,draw_8,draw_9,draw_10]
def draw(c,i,t):
    SCENES[i](c,t)
