#!/usr/bin/env python3
"""Small, conservative CSV/XLSX cleanup CLI. See README.md for the data contract."""
from __future__ import annotations

import argparse
import csv
import json
import os
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime, time
from pathlib import Path
import sys
import tempfile
import zipfile
from xml.etree.ElementTree import ParseError

VERSION = "1.0.0"
MAX_BYTES = 25 * 1024 * 1024
MAX_EXPANDED_BYTES = 100 * 1024 * 1024
MAX_ROWS = 100_000
MAX_COLUMNS = 200
MAX_CELL = 32_767
META = ["_source_file", "_source_sheet", "_source_row", "_issues"]
OUTPUTS = ["cleaned.csv", "review.csv", "duplicates.csv", "summary.json", "summary.txt"]


class CleanupError(Exception):
    """An input or output problem the user can fix."""


@dataclass
class Record:
    values: tuple[str, ...]
    source_file: str
    source_sheet: str
    source_row: int
    issues: list[str] = field(default_factory=list)

    def location(self):
        return f"{self.source_file}:{self.source_sheet or 'CSV'}:record {self.source_row}"


def plain_text(value):
    if value is None:
        return ""
    if isinstance(value, (datetime, date, time)):
        return value.isoformat()
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    return str(value)


def normalize(value):
    text = plain_text(value)
    if "\0" in text or len(text) > MAX_CELL:
        raise CleanupError("A cell contains a NUL character or exceeds 32,767 characters.")
    return text.strip(), text != text.strip()


def csv_safe(value):
    """Neutralize formula-like text without ever evaluating it."""
    text = str(value)
    return "'" + text if text.lstrip().startswith(("=", "+", "-", "@")) else text


def raw_input(path: Path, sheet_name: str | None):
    if not path.is_file():
        raise CleanupError(f"Input is not a readable file: {path}")
    if path.stat().st_size > MAX_BYTES:
        raise CleanupError(f"Input exceeds the 25 MiB limit: {path.name}")
    suffix = path.suffix.lower()
    if suffix == ".csv":
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            # Strict parsing catches unterminated quotes instead of inventing cells.
            reader = csv.reader(handle, strict=True)
            rows = []
            for row in reader:
                rows.append(row)
                if len(rows) > MAX_ROWS + 1:
                    raise CleanupError(f"More than {MAX_ROWS:,} data records in {path.name}")
        return rows, ""
    if suffix != ".xlsx":
        raise CleanupError(f"Unsupported input {path.name}; use .csv or .xlsx (no .xls/.xlsm).")
    with zipfile.ZipFile(path) as archive:
        if sum(info.file_size for info in archive.infolist()) > MAX_EXPANDED_BYTES:
            raise CleanupError(f"Expanded workbook exceeds 100 MiB: {path.name}")
        if any("vbaproject" in name.lower() for name in archive.namelist()):
            raise CleanupError(f"Macro content is not supported: {path.name}")
    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise CleanupError("XLSX input needs openpyxl. Run: python -m pip install -r requirements.txt") from exc
    with path.open("rb") as workbook_file:
        workbook = load_workbook(workbook_file, read_only=True, data_only=False, keep_links=False)
        try:
            if sheet_name:
                if sheet_name not in workbook.sheetnames:
                    raise CleanupError(f"Sheet {sheet_name!r} not found in {path.name}: {workbook.sheetnames}")
                sheet = workbook[sheet_name]
            elif len(workbook.sheetnames) == 1:
                sheet = workbook.worksheets[0]
            else:
                raise CleanupError(f"{path.name} has multiple sheets. Select one explicitly with --sheet NAME.")
            # Exporters can declare incorrect dimensions. Read actual cells and enforce
            # limits while iterating so an undersized declaration cannot drop records.
            sheet.reset_dimensions()
            rows = []
            for cells in sheet.iter_rows():
                if len(rows) > MAX_ROWS or len(cells) > MAX_COLUMNS:
                    raise CleanupError("Workbook exceeds row/column safety limits.")
                row = []
                for cell in cells:
                    if cell.data_type in ("f", "e"):
                        raise CleanupError(f"Formula/error cell {path.name}!{sheet.title}!{cell.coordinate}; export verified values first.")
                    row.append(cell.value)
                rows.append(row)
            # Ignore trailing empty layout cells; internal blank records remain reviewable.
            while rows and all(value is None for value in rows[-1]):
                rows.pop()
            if rows:
                used_columns = max((i + 1 for row in rows for i, v in enumerate(row) if v is not None), default=0)
                rows = [row[:used_columns] + [None] * max(0, used_columns - len(row)) for row in rows]
            return rows, sheet.title
        finally:
            workbook.close()


def read_records(paths, keys, sheet_name=None):
    headers = None
    records = []
    trimmed = 0
    sources = []
    for path in paths:
        raw_rows, sheet = raw_input(path, sheet_name)
        if not raw_rows:
            raise CleanupError(f"No header row in {path.name}")
        input_headers = [normalize(value)[0] for value in raw_rows[0]]
        if not input_headers or len(input_headers) > MAX_COLUMNS:
            raise CleanupError(f"Use 1 to {MAX_COLUMNS} columns in {path.name}")
        if any(not h for h in input_headers) or len(set(input_headers)) != len(input_headers):
            raise CleanupError(f"Blank or duplicate headers in {path.name} (after trimming).")
        reserved = set(input_headers) & set(META + ["_duplicate_of"])
        if reserved:
            raise CleanupError(f"Reserved column names in {path.name}: {sorted(reserved)}")
        if headers is None:
            headers = input_headers
            missing_keys = set(keys) - set(headers)
            if missing_keys:
                raise CleanupError(f"Deduplication keys not present in headers: {sorted(missing_keys)}")
        elif set(input_headers) != set(headers):
            missing = sorted(set(headers) - set(input_headers))
            extra = sorted(set(input_headers) - set(headers))
            raise CleanupError(f"Schema mismatch in {path.name}. Missing: {missing}; extra: {extra}")
        order = [input_headers.index(h) for h in headers]
        key_indices = [input_headers.index(key) for key in keys]
        for number, raw in enumerate(raw_rows[1:], start=2):
            # An empty physical CSV record means an entirely missing row, not a deletion.
            if not raw:
                raw = [""] * len(input_headers)
            if len(raw) != len(input_headers):
                raise CleanupError(f"{path.name}: record {number} has {len(raw)} cells; expected {len(input_headers)}.")
            if path.suffix.lower() == ".xlsx":
                for index in key_indices:
                    if raw[index] is not None and not isinstance(raw[index], str):
                        raise CleanupError(f"{path.name}: record {number}, key {input_headers[index]!r} is not stored as text. Convert identifiers to text in the source; lost leading zeros cannot be recovered.")
            values = []
            for index in order:
                value, changed = normalize(raw[index])
                values.append(value)
                trimmed += changed
            records.append(Record(tuple(values), path.name, sheet, number))
            if len(records) > MAX_ROWS:
                raise CleanupError(f"Combined inputs exceed {MAX_ROWS:,} records.")
        sources.append({"file": path.name, "sheet": sheet, "data_records": len(raw_rows) - 1})
    return headers, records, trimmed, sources


def clean_records(headers, records, keys):
    indices = [headers.index(key) for key in keys]
    variants = defaultdict(set)
    for record in records:
        key = tuple(record.values[i] for i in indices)
        if all(key):
            variants[key].add(record.values)
    seen = {}
    kept, removed = [], []
    for record in records:
        key = tuple(record.values[i] for i in indices)
        missing = [name for name, value in zip(headers, record.values) if not value]
        if missing:
            record.issues.append("missing:" + "|".join(missing))
        if not all(key):
            record.issues.append("missing_key:retained")
        elif len(variants[key]) > 1:
            record.issues.append("key_conflict:retained")
        if all(key) and record.values in seen:
            removed.append((record, seen[record.values]))
        else:
            kept.append(record)
            if all(key):
                seen[record.values] = record
    return kept, removed, sum(len(values) > 1 for values in variants.values())


def record_row(record):
    return [*record.values, record.source_file, record.source_sheet, record.source_row, "; ".join(record.issues)]


def write_csv(path, headers, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle, quoting=csv.QUOTE_ALL)
        writer.writerow([csv_safe(h) for h in headers])
        for row in rows:
            writer.writerow([csv_safe(value) for value in row])


def summary_text(summary):
    stats = summary["counts"]
    return "\n".join([
        "CSV + XLSX CLEANUP | RUN SUMMARY",
        "=" * 42,
        f"Input files: {len(summary['inputs'])}",
        f"Input records: {stats['input_records']}",
        f"Output records: {stats['output_records']}",
        f"Exact duplicates removed: {stats['duplicates_removed']}",
        f"Rows needing review: {stats['review_rows']}",
        f"Missing cells (input / output): {stats['missing_cells_before']} / {stats['missing_cells_after']}",
        f"Conflicting key groups retained: {stats['conflicting_key_groups']}",
        f"Cells trimmed: {stats['cells_trimmed']}",
        f"Formula-like data cells protected in cleaned.csv: {stats['protected_output_data_cells']}",
        "", "RULES",
        "Keys: " + ", ".join(summary["rules"]["dedupe_keys"]),
        "Trim outer whitespace. Case-sensitive, exact whole-row comparison.",
        "Remove repeated identical rows only when all chosen keys are present.",
        "Retain distinct conflicting rows and every row with an incomplete key.",
        "Blank values are flagged, never filled or silently dropped.",
        "Every CSV cell starting with =, +, -, or @ gets an apostrophe prefix.",
        "", "REVIEW FIRST",
        "Open review.csv and resolve missing values/key conflicts with the data owner.",
        "duplicates.csv records removals and the retained source record.",
        "For Excel, import CSV columns as Text to preserve leading-zero identifiers.",
        "Original input files were not modified.", "",
    ])


def validate_destination(destination, paths, overwrite):
    if destination.is_symlink():
        raise CleanupError("Output directory must not be a symbolic link.")
    if destination.exists():
        if not destination.is_dir():
            raise CleanupError("Output path is not a directory.")
        if not overwrite:
            raise CleanupError("Output directory already exists. Choose a new directory or explicitly use --overwrite.")
        contents = list(destination.iterdir())
        if any(p.name not in OUTPUTS or p.is_symlink() or not p.is_file() for p in contents):
            raise CleanupError("--overwrite accepts only a directory containing this tool's regular output files; unrelated files/symlinks are not replaced.")
    outputs = {(destination / name).resolve() for name in OUTPUTS}
    if any(path.resolve() in outputs for path in paths):
        raise CleanupError("An output path is an input file; originals cannot be overwritten.")
    if destination.exists():
        for target in destination.iterdir():
            if any(os.path.samefile(target, source) for source in paths):
                raise CleanupError("An output is linked to an input file; originals cannot be overwritten.")


def run(paths, output_dir, keys, policy, sheet=None, overwrite=False):
    if policy != "exact-only" or not keys or len(keys) != len(set(keys)):
        raise CleanupError("Provide unique --dedupe-key column(s) and --dedupe-policy exact-only.")
    paths = [Path(path).resolve() for path in paths]
    if not paths or len(paths) != len(set(paths)):
        raise CleanupError("Provide at least one input, and do not repeat an input file.")
    for index, path in enumerate(paths):
        if any(path.is_file() and earlier.is_file() and os.path.samefile(path, earlier) for earlier in paths[:index]):
            raise CleanupError("Do not repeat an input file through a hard link.")
    if len({path.name for path in paths}) != len(paths):
        raise CleanupError("Input basenames must be unique so source lineage is unambiguous.")
    output_dir = Path(output_dir).absolute()
    validate_destination(output_dir, paths, overwrite)
    headers, records, trimmed, sources = read_records(paths, keys, sheet)
    kept, removed, conflicts = clean_records(headers, records, keys)
    review = [record for record in kept if record.issues]
    summary = {
        "tool": "portfolio-cleanup", "version": VERSION,
        "inputs": sources,
        "rules": {"dedupe_keys": keys, "dedupe_policy": policy, "normalization": "outer whitespace only; case-sensitive", "missing": "empty after trimming; retained and flagged", "csv_formula_protection": "apostrophe prefix for = + - @"},
        "counts": {
            "input_records": len(records), "output_records": len(kept), "duplicates_removed": len(removed),
            "review_rows": len(review), "missing_cells_before": sum(value == "" for record in records for value in record.values),
            "missing_cells_after": sum(value == "" for record in kept for value in record.values),
            "conflicting_key_groups": conflicts, "cells_trimmed": trimmed,
            "protected_output_data_cells": sum(csv_safe(value) != value for record in kept for value in record.values),
        },
    }
    # Prepare the complete batch first. No final output exists if reading/writing fails.
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".cleanup-", dir=output_dir.parent) as temporary:
        staging = Path(temporary)
        columns = headers + META
        write_csv(staging / "cleaned.csv", columns, map(record_row, kept))
        write_csv(staging / "review.csv", columns, map(record_row, review))
        write_csv(staging / "duplicates.csv", columns + ["_duplicate_of"], (record_row(record) + [original.location()] for record, original in removed))
        (staging / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        (staging / "summary.txt").write_text(summary_text(summary), encoding="utf-8")
        validate_destination(output_dir, paths, overwrite)
        if not output_dir.exists():
            output_dir.mkdir()  # Exclusive creation also protects against accidental concurrent runs.
        for name in OUTPUTS:
            target = output_dir / name
            if overwrite:
                os.replace(staging / name, target)
            else:
                # Exclusive create ensures even an unexpected concurrent file is not overwritten.
                with target.open("xb") as handle:
                    handle.write((staging / name).read_bytes())
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", nargs="+", required=True, type=Path, help="UTF-8 CSV or value-only XLSX files")
    parser.add_argument("--output-dir", required=True, type=Path, help="New directory for five output files")
    parser.add_argument("--dedupe-key", nargs="+", required=True, help="Exact column name(s); agree these with the data owner")
    parser.add_argument("--dedupe-policy", choices=["exact-only"], required=True)
    parser.add_argument("--sheet", help="Explicit sheet name, applied to every XLSX input")
    parser.add_argument("--overwrite", action="store_true", help="Explicitly replace this tool's outputs in an existing directory")
    parser.add_argument("--version", action="version", version=VERSION)
    args = parser.parse_args(argv)
    try:
        summary = run(args.input, args.output_dir, args.dedupe_key, args.dedupe_policy, args.sheet, args.overwrite)
    except (CleanupError, OSError, UnicodeError, csv.Error, zipfile.BadZipFile, ValueError, KeyError, ParseError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    print(summary_text(summary), end="")
    print(f"Saved to: {args.output_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
