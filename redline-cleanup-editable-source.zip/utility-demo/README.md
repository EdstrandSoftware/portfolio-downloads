# CSV cleanup utility

Start with `../WORKFLOW.md` at the package root for setup, commands, expected
outputs, limitations, and the simulated revision. This folder contains the
runnable utility and fictional examples.
